# Telegram School Bot (GitHub Ready)

This folder is ready to upload to GitHub and deploy for free using **Railway** or **Glitch**.

## 🚀 Railway Deploy Steps
1. Push this folder to a new **GitHub repository**
2. Go to [https://railway.app](https://railway.app)
3. Click **New Project → Deploy from GitHub Repo**
4. Add Environment Variable:
   ```
   BOT_TOKEN=your_telegram_bot_token
   ```
5. Railway will install dependencies and run automatically.

## 💻 Local Run
```bash
npm install
npm start
```
