import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertCircle, XCircle, Bot, Globe, Settings } from "lucide-react";

interface BotStatusData {
  status: string;
  botInfo?: {
    id: number;
    is_bot: boolean;
    first_name: string;
    username: string;
    can_join_groups: boolean;
    can_read_all_group_messages: boolean;
    supports_inline_queries: boolean;
  };
  webhookUrl?: string;
  message?: string;
}

interface BotStatusProps {
  status?: BotStatusData;
  isLoading: boolean;
}

export default function BotStatus({ status, isLoading }: BotStatusProps) {
  const getStatusIcon = (statusType: string) => {
    switch (statusType) {
      case 'active':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'inactive':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (statusType: string) => {
    switch (statusType) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800">Error</Badge>;
      case 'inactive':
        return <Badge className="bg-yellow-100 text-yellow-800">Inactive</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[...Array(2)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-1/3"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
                <div className="h-4 bg-muted rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Bot Status Overview */}
      <Card data-testid="bot-status-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bot className="w-5 h-5" />
            <span>Bot Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Status:</span>
            <div className="flex items-center space-x-2">
              {status && getStatusIcon(status.status)}
              {status && getStatusBadge(status.status)}
            </div>
          </div>

          {status?.botInfo && (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Bot Name:</span>
                <span className="text-sm">{status.botInfo.first_name}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Username:</span>
                <span className="text-sm font-mono">@{status.botInfo.username}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Bot ID:</span>
                <span className="text-sm font-mono">{status.botInfo.id}</span>
              </div>
            </>
          )}

          {status?.message && (
            <div className="bg-muted/50 p-3 rounded-lg">
              <p className="text-sm text-muted-foreground">{status.message}</p>
            </div>
          )}

          {status?.status === 'active' && (
            <div className="pt-2">
              <Button variant="outline" size="sm" className="w-full">
                <Settings className="w-4 h-4 mr-2" />
                Configure Bot
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bot Capabilities */}
      <Card data-testid="bot-capabilities-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="w-5 h-5" />
            <span>Bot Capabilities</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {status?.botInfo ? (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Can Join Groups:</span>
                <Badge variant={status.botInfo.can_join_groups ? "default" : "secondary"}>
                  {status.botInfo.can_join_groups ? "Yes" : "No"}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Read Group Messages:</span>
                <Badge variant={status.botInfo.can_read_all_group_messages ? "default" : "secondary"}>
                  {status.botInfo.can_read_all_group_messages ? "Yes" : "No"}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Inline Queries:</span>
                <Badge variant={status.botInfo.supports_inline_queries ? "default" : "secondary"}>
                  {status.botInfo.supports_inline_queries ? "Supported" : "Not Supported"}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Webhook URL:</span>
                <span className="text-xs font-mono bg-muted px-2 py-1 rounded">
                  {status.webhookUrl ? "Configured" : "Not Set"}
                </span>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">
                Bot information not available
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Connection Info */}
      <Card data-testid="connection-info-card">
        <CardHeader>
          <CardTitle>Connection Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Webhook:</span>
            <Badge variant={status?.webhookUrl ? "default" : "secondary"}>
              {status?.webhookUrl ? "Active" : "Not Configured"}
            </Badge>
          </div>

          {status?.webhookUrl && (
            <div className="bg-muted/50 p-3 rounded-lg">
              <p className="text-xs font-mono break-all">{status.webhookUrl}</p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Last Health Check:</span>
            <span className="text-sm text-muted-foreground">
              {new Date().toLocaleTimeString()}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card data-testid="quick-actions-card">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button 
            variant="outline" 
            className="w-full justify-start"
            data-testid="test-bot-button"
          >
            <Bot className="w-4 h-4 mr-2" />
            Test Bot Connection
          </Button>

          <Button 
            variant="outline" 
            className="w-full justify-start"
            data-testid="view-logs-button"
          >
            <Settings className="w-4 h-4 mr-2" />
            View Bot Logs
          </Button>

          <Button 
            variant="outline" 
            className="w-full justify-start"
            data-testid="refresh-status-button"
          >
            <Globe className="w-4 h-4 mr-2" />
            Refresh Status
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
