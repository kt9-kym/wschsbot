import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, Users } from "lucide-react";

const broadcastFormSchema = z.object({
  message: z.string().min(10, "Message must be at least 10 characters"),
  targetGrade: z.string().optional(),
  targetGroups: z.array(z.string()).optional(),
});

type BroadcastFormData = z.infer<typeof broadcastFormSchema>;

interface Group {
  id: string;
  name: string;
  grade?: string;
  subject?: string;
}

interface BroadcastFormProps {
  groups: Group[];
  onSubmit: (data: BroadcastFormData) => void;
  isLoading?: boolean;
}

export default function BroadcastForm({ groups, onSubmit, isLoading = false }: BroadcastFormProps) {
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [broadcastMode, setBroadcastMode] = useState<'all' | 'grade' | 'groups'>('all');

  const form = useForm<BroadcastFormData>({
    resolver: zodResolver(broadcastFormSchema),
    defaultValues: {
      message: "",
      targetGrade: "",
      targetGroups: [],
    },
  });

  const handleSubmit = (data: BroadcastFormData) => {
    const submitData: BroadcastFormData = {
      message: data.message,
    };

    if (broadcastMode === 'grade' && data.targetGrade) {
      submitData.targetGrade = data.targetGrade;
    } else if (broadcastMode === 'groups' && selectedGroups.length > 0) {
      submitData.targetGroups = selectedGroups;
    }

    onSubmit(submitData);
  };

  const handleGroupSelection = (groupId: string, checked: boolean) => {
    if (checked) {
      setSelectedGroups([...selectedGroups, groupId]);
    } else {
      setSelectedGroups(selectedGroups.filter(id => id !== groupId));
    }
  };

  const messageTemplates = [
    {
      title: "Homework Reminder",
      content: "📝 Reminder: Don't forget to complete your homework assignments. Use /homework to view current assignments."
    },
    {
      title: "Exam Announcement",
      content: "📊 Important: Upcoming exams next week. Use /quiz to practice and prepare. Good luck!"
    },
    {
      title: "New Resources",
      content: "📚 New study materials have been added! Use /books to access the latest resources for your grade."
    },
    {
      title: "Bot Update",
      content: "🤖 Bot has been updated with new features! Try /ask to get AI-powered answers to your questions."
    }
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        {/* Broadcast Mode Selection */}
        <div className="space-y-4">
          <FormLabel>Broadcast Target</FormLabel>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card 
              className={`cursor-pointer transition-colors ${broadcastMode === 'all' ? 'border-primary bg-primary/5' : ''}`}
              onClick={() => setBroadcastMode('all')}
              data-testid="broadcast-all-option"
            >
              <CardContent className="p-4 text-center">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-medium">All Groups</h3>
                <p className="text-sm text-muted-foreground">Send to all active groups</p>
              </CardContent>
            </Card>

            <Card 
              className={`cursor-pointer transition-colors ${broadcastMode === 'grade' ? 'border-primary bg-primary/5' : ''}`}
              onClick={() => setBroadcastMode('grade')}
              data-testid="broadcast-grade-option"
            >
              <CardContent className="p-4 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-medium">By Grade</h3>
                <p className="text-sm text-muted-foreground">Send to specific grade</p>
              </CardContent>
            </Card>

            <Card 
              className={`cursor-pointer transition-colors ${broadcastMode === 'groups' ? 'border-primary bg-primary/5' : ''}`}
              onClick={() => setBroadcastMode('groups')}
              data-testid="broadcast-groups-option"
            >
              <CardContent className="p-4 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-primary" />
                <h3 className="font-medium">Select Groups</h3>
                <p className="text-sm text-muted-foreground">Choose specific groups</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Grade Selection */}
        {broadcastMode === 'grade' && (
          <FormField
            control={form.control}
            name="targetGrade"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Select Grade</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="target-grade-select">
                      <SelectValue placeholder="Select grade to broadcast to" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Grade 9">Grade 9</SelectItem>
                    <SelectItem value="Grade 10">Grade 10</SelectItem>
                    <SelectItem value="Grade 11">Grade 11</SelectItem>
                    <SelectItem value="Grade 12">Grade 12</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        {/* Group Selection */}
        {broadcastMode === 'groups' && (
          <div className="space-y-4">
            <FormLabel>Select Groups</FormLabel>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-64 overflow-y-auto">
              {groups.map((group) => (
                <div 
                  key={group.id} 
                  className="flex items-center space-x-2 p-3 border rounded-lg"
                  data-testid={`group-option-${group.id}`}
                >
                  <Checkbox
                    id={group.id}
                    checked={selectedGroups.includes(group.id)}
                    onCheckedChange={(checked) => handleGroupSelection(group.id, checked as boolean)}
                  />
                  <label htmlFor={group.id} className="flex-1 cursor-pointer">
                    <div>
                      <p className="font-medium text-sm">{group.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {group.grade && `${group.grade} • `}
                        {group.subject || 'General'}
                      </p>
                    </div>
                  </label>
                </div>
              ))}
            </div>
            {groups.length === 0 && (
              <p className="text-sm text-muted-foreground">No groups available</p>
            )}
          </div>
        )}

        {/* Message Templates */}
        <div className="space-y-4">
          <FormLabel>Message Templates (Optional)</FormLabel>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {messageTemplates.map((template, index) => (
              <Card 
                key={index}
                className="cursor-pointer hover:border-primary transition-colors"
                onClick={() => form.setValue('message', template.content)}
                data-testid={`template-${index}`}
              >
                <CardContent className="p-4">
                  <h3 className="font-medium text-sm mb-2">{template.title}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {template.content}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Message Input */}
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Broadcast Message *</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Type your message here..." 
                  className="min-h-[120px]"
                  {...field}
                  data-testid="broadcast-message-input"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Preview */}
        {form.watch('message') && (
          <div className="bg-muted/50 p-4 rounded-lg">
            <FormLabel className="text-sm font-medium">Preview:</FormLabel>
            <div className="mt-2 p-3 bg-white border rounded-lg">
              <p className="text-sm whitespace-pre-wrap">{form.watch('message')}</p>
            </div>
          </div>
        )}

        {/* Submit */}
        <div className="flex justify-end space-x-2 pt-4">
          <Button 
            type="submit" 
            disabled={isLoading}
            data-testid="send-broadcast-button"
          >
            {isLoading ? "Sending..." : "Send Broadcast"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
