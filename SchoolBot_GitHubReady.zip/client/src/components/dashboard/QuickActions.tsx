import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Users, PenTool, MessageSquare } from "lucide-react";

const quickActions = [
  {
    title: "Add Exam Questions",
    icon: Plus,
    bgColor: "bg-primary/10",
    hoverBg: "group-hover:bg-primary",
    iconColor: "text-primary",
    hoverIconColor: "group-hover:text-primary-foreground",
    action: "/exam-questions"
  },
  {
    title: "Create Group",
    icon: Users,
    bgColor: "bg-secondary/10",
    hoverBg: "group-hover:bg-secondary",
    iconColor: "text-secondary",
    hoverIconColor: "group-hover:text-white",
    action: "/groups"
  },
  {
    title: "Upload Homework",
    icon: PenTool,
    bgColor: "bg-accent/10",
    hoverBg: "group-hover:bg-accent",
    iconColor: "text-accent",
    hoverIconColor: "group-hover:text-accent-foreground",
    action: "/homework"
  },
  {
    title: "Broadcast Message",
    icon: MessageSquare,
    bgColor: "bg-purple-100",
    hoverBg: "group-hover:bg-purple-600",
    iconColor: "text-purple-600",
    hoverIconColor: "group-hover:text-white",
    action: "/bot-settings"
  }
];

export default function QuickActions() {
  const handleAction = (action: string) => {
    window.location.href = action;
  };

  return (
    <Card data-testid="quick-actions-card">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Button
                key={index}
                variant="outline"
                className="p-4 h-auto border border-border rounded-lg hover:bg-muted/50 transition-colors text-center group flex flex-col items-center space-y-3"
                onClick={() => handleAction(action.action)}
                data-testid={`quick-action-${action.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className={`${action.bgColor} ${action.hoverBg} p-3 rounded-lg transition-colors`}>
                  <Icon className={`w-6 h-6 ${action.iconColor} ${action.hoverIconColor} transition-colors`} />
                </div>
                <span className="text-sm font-medium text-foreground">{action.title}</span>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
