import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Users, HelpCircle, PenTool, UserPlus } from "lucide-react";

interface ActivityItem {
  type: string;
  description: string;
  timestamp: string;
  icon: string;
}

function getActivityIcon(iconType: string) {
  switch (iconType) {
    case 'user':
    case 'student':
      return UserPlus;
    case 'ai':
      return HelpCircle;
    case 'homework':
      return PenTool;
    default:
      return Users;
  }
}

export default function RecentActivity() {
  const { data: activities = [], isLoading } = useQuery<ActivityItem[]>({
    queryKey: ['/api/dashboard/activity'],
  });

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    const hours = Math.floor(diffInMinutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <Card data-testid="recent-activity-card">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground">Recent Bot Activity</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50 animate-pulse">
                <div className="bg-primary/20 rounded-full p-1 w-8 h-8"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : activities.length === 0 ? (
          <p className="text-muted-foreground text-center py-4">No recent activity</p>
        ) : (
          <div className="space-y-4">
            {activities.slice(0, 5).map((activity, index) => {
              const IconComponent = getActivityIcon(activity.icon);
              return (
                <div 
                  key={index} 
                  className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50"
                  data-testid={`activity-item-${index}`}
                >
                  <div className="bg-primary text-primary-foreground rounded-full p-1">
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">{formatTimeAgo(activity.timestamp)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        
        <Button 
          variant="ghost" 
          className="w-full mt-4 text-sm text-primary hover:text-primary/80 font-medium"
          data-testid="view-all-activity-button"
        >
          View All Activity
        </Button>
      </CardContent>
    </Card>
  );
}
