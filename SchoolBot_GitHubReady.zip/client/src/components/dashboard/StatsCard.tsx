import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  description: string;
  icon: LucideIcon;
  trend?: {
    value: string;
    positive: boolean;
  };
  iconBgColor?: string;
  iconColor?: string;
}

export default function StatsCard({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend,
  iconBgColor = "bg-primary/10",
  iconColor = "text-primary"
}: StatsCardProps) {
  return (
    <Card className="stat-card hover:shadow-lg transition-all duration-200" data-testid={`stats-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold text-foreground">{value}</p>
            {trend && (
              <p className={`text-xs mt-1 ${trend.positive ? 'text-secondary' : 'text-destructive'}`}>
                {trend.value}
              </p>
            )}
            {!trend && description && (
              <p className="text-xs text-muted-foreground mt-1">{description}</p>
            )}
          </div>
          <div className={`${iconBgColor} p-3 rounded-lg`}>
            <Icon className={`w-6 h-6 ${iconColor}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
