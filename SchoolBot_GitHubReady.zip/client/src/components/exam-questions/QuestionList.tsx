import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, X, Eye } from "lucide-react";
import { type ExamQuestion } from "@shared/schema";

interface QuestionListProps {
  questions: ExamQuestion[];
  isLoading?: boolean;
}

export default function QuestionList({ questions, isLoading = false }: QuestionListProps) {
  const getDifficultyBadgeColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSubjectBadgeColor = (subject: string) => {
    const colors = {
      'Mathematics': 'bg-blue-100 text-blue-800',
      'English': 'bg-green-100 text-green-800',
      'Biology': 'bg-purple-100 text-purple-800',
      'Chemistry': 'bg-orange-100 text-orange-800',
      'Physics': 'bg-indigo-100 text-indigo-800',
      'Geography': 'bg-teal-100 text-teal-800',
      'Civics': 'bg-pink-100 text-pink-800',
    };
    return colors[subject as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="h-4 bg-muted rounded w-1/4"></div>
                  <div className="h-6 bg-muted rounded w-16"></div>
                </div>
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="space-y-2">
                  {[...Array(4)].map((_, j) => (
                    <div key={j} className="h-3 bg-muted rounded w-full"></div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-muted-foreground mb-4">
          No exam questions found. Start by adding questions or uploading from the Ethiopian question bank.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {questions.map((question) => {
        const options = Array.isArray(question.options) ? question.options : JSON.parse(question.options as string);
        
        return (
          <Card key={question.id} data-testid={`question-card-${question.id}`}>
            <CardContent className="p-6">
              <div className="space-y-4">
                {/* Question Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge className={getSubjectBadgeColor(question.subject)}>
                        {question.subject}
                      </Badge>
                      <Badge variant="outline">
                        {question.examType} - {question.grade}
                      </Badge>
                      <Badge className={getDifficultyBadgeColor(question.difficulty || 'medium')}>
                        {question.difficulty || 'medium'}
                      </Badge>
                      {question.year && (
                        <Badge variant="secondary">
                          {question.year}
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-medium text-foreground text-lg">
                      {question.question}
                    </h3>
                  </div>
                  <Button variant="ghost" size="sm" data-testid={`view-question-${question.id}`}>
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>

                {/* Answer Options */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {options.map((option: string, index: number) => {
                    const letter = String.fromCharCode(65 + index);
                    const isCorrect = question.correctAnswer === letter;
                    
                    return (
                      <div 
                        key={index}
                        className={`flex items-center space-x-2 p-3 rounded-lg border ${
                          isCorrect 
                            ? 'border-green-200 bg-green-50' 
                            : 'border-border bg-card'
                        }`}
                        data-testid={`option-${question.id}-${index}`}
                      >
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                          isCorrect 
                            ? 'bg-green-500 text-white' 
                            : 'bg-muted text-muted-foreground'
                        }`}>
                          {letter}
                        </div>
                        <span className={`flex-1 text-sm ${
                          isCorrect ? 'text-green-900 font-medium' : 'text-foreground'
                        }`}>
                          {option}
                        </span>
                        {isCorrect && (
                          <Check className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                {question.explanation && (
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-sm font-medium text-foreground mb-1">Explanation:</p>
                    <p className="text-sm text-muted-foreground">{question.explanation}</p>
                  </div>
                )}

                {/* Question Footer */}
                <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                  <div className="flex items-center space-x-4">
                    <span>Source: {question.source}</span>
                    <span>Created: {new Date(question.createdAt || '').toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span>ID: {question.id.slice(-8)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
