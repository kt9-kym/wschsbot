import { useLocation } from "wouter";
import { 
  BarChart3, 
  Users, 
  GraduationCap, 
  FileText, 
  BookOpen, 
  PenTool, 
  HelpCircle, 
  UsersIcon, 
  Settings, 
  Image, 
  Info 
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigationItems = [
  {
    title: "Dashboard",
    items: [
      { name: "Overview", href: "/", icon: BarChart3 },
      { name: "Students", href: "/students", icon: Users },
      { name: "Teachers", href: "/teachers", icon: GraduationCap },
    ]
  },
  {
    title: "Academic",
    items: [
      { name: "Exam Questions", href: "/exam-questions", icon: FileText },
      { name: "Books & Resources", href: "/books", icon: BookOpen },
      { name: "Homework", href: "/homework", icon: PenTool },
      { name: "AI Q&A", href: "/ai-qa", icon: HelpCircle },
    ]
  },
  {
    title: "Bot Management",
    items: [
      { name: "Groups", href: "/groups", icon: UsersIcon },
      { name: "Analytics", href: "/analytics", icon: BarChart3 },
      { name: "Bot Settings", href: "/bot-settings", icon: Settings },
    ]
  },
  {
    title: "School",
    items: [
      { name: "Gallery", href: "/gallery", icon: Image },
      { name: "School Info", href: "/school-info", icon: Info },
    ]
  }
];

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();

  return (
    <aside className={cn("w-64 bg-card border-r border-border min-h-screen", className)}>
      <nav className="p-4 space-y-2">
        {navigationItems.map((section) => (
          <div key={section.title} className="mb-6">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              {section.title}
            </h2>
            <ul className="space-y-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                
                return (
                  <li key={item.name}>
                    <a
                      href={item.href}
                      className={cn(
                        "nav-item flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors",
                        isActive 
                          ? "active bg-primary text-primary-foreground" 
                          : "text-foreground hover:bg-muted"
                      )}
                      data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{item.name}</span>
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
