import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageCircle, Calendar, User } from "lucide-react";
import { type Student } from "@shared/schema";

interface StudentTableProps {
  students: Student[];
}

export default function StudentTable({ students }: StudentTableProps) {
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString();
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(part => part[0]).join('').toUpperCase().slice(0, 2);
  };

  const getGradeBadgeColor = (grade: string) => {
    switch (grade) {
      case 'Grade 9': return 'bg-blue-100 text-blue-800';
      case 'Grade 10': return 'bg-green-100 text-green-800';
      case 'Grade 11': return 'bg-yellow-100 text-yellow-800';
      case 'Grade 12': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student</TableHead>
            <TableHead>Grade & Section</TableHead>
            <TableHead>Stream</TableHead>
            <TableHead>Telegram</TableHead>
            <TableHead>Registered</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {students.map((student) => (
            <TableRow key={student.id} data-testid={`student-row-${student.id}`}>
              <TableCell>
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {getInitials(student.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-foreground">{student.name}</p>
                    <p className="text-sm text-muted-foreground">ID: {student.id.slice(-8)}</p>
                  </div>
                </div>
              </TableCell>
              
              <TableCell>
                <div className="space-y-1">
                  <Badge className={getGradeBadgeColor(student.grade)}>
                    {student.grade}
                  </Badge>
                  {student.section && (
                    <p className="text-sm text-muted-foreground">Section {student.section}</p>
                  )}
                </div>
              </TableCell>
              
              <TableCell>
                {student.stream ? (
                  <Badge variant="outline">{student.stream}</Badge>
                ) : (
                  <span className="text-muted-foreground">-</span>
                )}
              </TableCell>
              
              <TableCell>
                <div className="space-y-1">
                  {student.telegramUsername ? (
                    <div className="flex items-center space-x-1">
                      <MessageCircle className="w-3 h-3 text-muted-foreground" />
                      <span className="text-sm">{student.telegramUsername}</span>
                    </div>
                  ) : (
                    <span className="text-muted-foreground">Not connected</span>
                  )}
                  {student.telegramId && (
                    <p className="text-xs text-muted-foreground">ID: {student.telegramId}</p>
                  )}
                </div>
              </TableCell>
              
              <TableCell>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-3 h-3 text-muted-foreground" />
                  <span className="text-sm">{formatDate(student.registeredAt?.toString())}</span>
                </div>
              </TableCell>
              
              <TableCell>
                <Badge variant={student.isActive ? "default" : "secondary"}>
                  {student.isActive ? "Active" : "Inactive"}
                </Badge>
              </TableCell>
              
              <TableCell>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    data-testid={`view-student-${student.id}`}
                  >
                    <User className="w-4 h-4" />
                  </Button>
                  {student.telegramId && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      data-testid={`message-student-${student.id}`}
                    >
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
