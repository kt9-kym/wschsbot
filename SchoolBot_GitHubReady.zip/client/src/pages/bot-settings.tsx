import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import BroadcastForm from "@/components/bot-settings/BroadcastForm";
import BotStatus from "@/components/bot-settings/BotStatus";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BotStatusData {
  status: string;
  botInfo?: any;
  webhookUrl?: string;
  message?: string;
}

interface Group {
  id: string;
  name: string;
  grade?: string;
  subject?: string;
}

export default function BotSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: botStatus, isLoading: statusLoading } = useQuery<BotStatusData>({
    queryKey: ['/api/bot/status'],
  });

  const { data: groups = [] } = useQuery<Group[]>({
    queryKey: ['/api/groups'],
  });

  const broadcastMutation = useMutation({
    mutationFn: async (data: { message: string; targetGrade?: string; targetGroups?: string[] }) => {
      return await apiRequest('POST', '/api/bot/broadcast', data);
    },
    onSuccess: (data: any) => {
      toast({
        title: "Success",
        description: `Message broadcasted to ${data.success} groups`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to broadcast message",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Bot Settings & Management</h1>
                <p className="text-muted-foreground mt-1">
                  Configure Telegram bot settings and broadcast messages
                </p>
              </div>
            </div>

            <Tabs defaultValue="status" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="status">Bot Status</TabsTrigger>
                <TabsTrigger value="broadcast">Broadcast</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="status" className="space-y-6">
                <BotStatus 
                  status={botStatus} 
                  isLoading={statusLoading} 
                />
              </TabsContent>

              <TabsContent value="broadcast" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Broadcast Message</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <BroadcastForm 
                      groups={groups}
                      onSubmit={(data) => broadcastMutation.mutate(data)}
                      isLoading={broadcastMutation.isPending}
                    />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="space-y-6">
                <BotSettingsTab />
              </TabsContent>

              <TabsContent value="analytics" className="space-y-6">
                <BotAnalyticsTab />
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}

function BotSettingsTab() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Bot Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Bot Token</label>
            <div className="mt-1 p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                Bot token is configured via environment variables for security
              </p>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Webhook URL</label>
            <div className="mt-1 p-3 bg-muted rounded-lg">
              <p className="text-sm font-mono text-muted-foreground">
                /api/telegram/webhook
              </p>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium">Admin ID</label>
            <div className="mt-1 p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                Admin ID is configured via environment variables
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>School Information Sync</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-4">
              Bot automatically syncs with school information from the database
            </p>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>School Name:</span>
                <span className="text-green-600">✓ Synced</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Vision & Mission:</span>
                <span className="text-green-600">✓ Synced</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Core Values:</span>
                <span className="text-green-600">✓ Synced</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Location:</span>
                <span className="text-green-600">✓ Synced</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>AI Assistant Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">OpenAI API</label>
            <div className="mt-1 p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                AI assistant powered by OpenAI GPT-5 for educational Q&A
              </p>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Language Support</label>
            <div className="mt-1 p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                English and Amharic support available
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Commands Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="font-mono">/start</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/help</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/homework</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/quiz</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/ask</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/books</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/groups</span>
              <span className="text-green-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono">/info</span>
              <span className="text-green-600">Active</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function BotAnalyticsTab() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Usage Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Total Messages</span>
              <span className="font-medium">Loading...</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Active Users (24h)</span>
              <span className="font-medium">Loading...</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">AI Queries</span>
              <span className="font-medium">Loading...</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Quiz Attempts</span>
              <span className="font-medium">Loading...</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Popular Commands</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-mono">/homework</span>
              <span className="text-sm text-muted-foreground">Loading...</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-mono">/ask</span>
              <span className="text-sm text-muted-foreground">Loading...</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-mono">/quiz</span>
              <span className="text-sm text-muted-foreground">Loading...</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-mono">/start</span>
              <span className="text-sm text-muted-foreground">Loading...</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Error Monitoring</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground">
              No recent errors detected
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Response Time</span>
              <span className="text-sm text-green-600">&lt; 1s</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Uptime</span>
              <span className="text-sm text-green-600">99.9%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Success Rate</span>
              <span className="text-sm text-green-600">98.5%</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
