import { useQuery } from "@tanstack/react-query";
import { Users, CheckCircle, FileText, HelpCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import StatsCard from "@/components/dashboard/StatsCard";
import RecentActivity from "@/components/dashboard/RecentActivity";
import QuickActions from "@/components/dashboard/QuickActions";

interface DashboardStats {
  totalStudents: number;
  activeBotUsers: number;
  examQuestions: number;
  aiQueries: number;
  examQuestionsBreakdown: Array<{
    examType: string;
    subject: string;
    count: number;
  }>;
}

interface SchoolInfo {
  key: string;
  value: string;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });

  const { data: schoolInfo = [] } = useQuery<SchoolInfo[]>({
    queryKey: ['/api/school-info'],
  });

  const getSchoolInfoValue = (key: string) => {
    return schoolInfo.find(info => info.key === key)?.value || '';
  };

  // Group exam questions by grade and exam type
  const examStatsGrouped = stats?.examQuestionsBreakdown.reduce((acc, item) => {
    const key = item.examType;
    if (!acc[key]) acc[key] = {};
    acc[key][item.subject] = item.count;
    return acc;
  }, {} as Record<string, Record<string, number>>) || {};

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {/* Dashboard Header */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
                <p className="text-muted-foreground mt-1">
                  Wolaita Soddo Comprehensive High School - Bot Management System
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Select defaultValue="today">
                  <SelectTrigger className="w-32" data-testid="time-filter-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                  </SelectContent>
                </Select>
                <Button data-testid="export-report-button">
                  Export Report
                </Button>
              </div>
            </div>

            {/* Statistics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatsCard
                title="Total Students"
                value={statsLoading ? "..." : stats?.totalStudents || 0}
                description="Registered users"
                icon={Users}
                trend={{ value: "+12% from last month", positive: true }}
                iconBgColor="bg-primary/10"
                iconColor="text-primary"
              />
              
              <StatsCard
                title="Active Bot Users"
                value={statsLoading ? "..." : stats?.activeBotUsers || 0}
                description="Daily active users"
                icon={CheckCircle}
                trend={{ value: "+8% from last week", positive: true }}
                iconBgColor="bg-secondary/10"
                iconColor="text-secondary"
              />
              
              <StatsCard
                title="Exam Questions"
                value={statsLoading ? "..." : stats?.examQuestions || 0}
                description="EGSECE & ESSLCE"
                icon={FileText}
                iconBgColor="bg-accent/10"
                iconColor="text-accent"
              />
              
              <StatsCard
                title="AI Queries Today"
                value={statsLoading ? "..." : stats?.aiQueries || 0}
                description="Students asking questions"
                icon={HelpCircle}
                iconBgColor="bg-purple-100"
                iconColor="text-purple-600"
              />
            </div>

            {/* Activity and Actions Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <RecentActivity />
              <QuickActions />
            </div>
          </div>

          {/* Exam Question Management Section */}
          <Card className="mb-8" data-testid="exam-questions-section">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-xl font-semibold text-foreground">
                    Ethiopian National Exam Questions
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    Manage EGSECE (Grade 10) and ESSLCE (Grade 12) exam question bank
                  </p>
                </div>
                <Button data-testid="upload-questions-button">
                  Upload New Questions
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* EGSECE Questions */}
                <Card className="border border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <FileText className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">EGSECE - Grade 10</h3>
                        <p className="text-sm text-muted-foreground">
                          Ethiopian General Secondary Education Certificate
                        </p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {Object.entries(examStatsGrouped.EGSECE || {}).map(([subject, count]) => (
                        <div key={subject} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{subject}:</span>
                          <span className="font-medium">{count} questions</span>
                        </div>
                      ))}
                      {Object.keys(examStatsGrouped.EGSECE || {}).length === 0 && (
                        <p className="text-sm text-muted-foreground">No questions uploaded yet</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* ESSLCE Questions */}
                <Card className="border border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="bg-secondary/10 p-2 rounded-lg">
                        <FileText className="w-5 h-5 text-secondary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">ESSLCE - Grade 12</h3>
                        <p className="text-sm text-muted-foreground">
                          Ethiopian Secondary School Leaving Certificate
                        </p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {Object.entries(examStatsGrouped.ESSLCE || {}).map(([subject, count]) => (
                        <div key={subject} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{subject}:</span>
                          <span className="font-medium">{count} questions</span>
                        </div>
                      ))}
                      {Object.keys(examStatsGrouped.ESSLCE || {}).length === 0 && (
                        <p className="text-sm text-muted-foreground">No questions uploaded yet</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          {/* School Information Integration */}
          <Card data-testid="school-info-section">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl font-semibold text-foreground">
                    School Information Display
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    Content synced from school website
                  </p>
                </div>
                <Button variant="ghost" className="text-primary hover:text-primary/80" data-testid="sync-website-button">
                  Sync with Website
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Vision</h3>
                    <p className="text-sm text-muted-foreground">
                      {getSchoolInfoValue('vision') || 'To nurture responsible citizens and future leaders through holistic education.'}
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Mission</h3>
                    <p className="text-sm text-muted-foreground">
                      {getSchoolInfoValue('mission') || 'To provide a safe, inclusive, and innovative learning environment that empowers every student to reach their full potential.'}
                    </p>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Core Values</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {(getSchoolInfoValue('values') || 'Integrity, Excellence, Respect, Collaboration, Service').split(',').map((value, index) => (
                      <li key={index}>• {value.trim()}</li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-semibold text-foreground mb-2">School Gallery</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <img 
                      src="https://z-p3-scontent.fadd2-1.fna.fbcdn.net/v/t39.30808-6/518250331_1042716144743265_6209946562434549136_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=833d8c&_nc_eui2=AeFf_a38cx7JIMaAQAd67-eIiTC5TtGVHsmJMLlO0ZUeySTHqwODcDrAhmvVbGeqyVdRUMrj2edXvyFgkZnJ9huR&_nc_ohc=w9TdEi3-klgQ7kNvwHJOOoV&_nc_oc=Adn8LFarleo7OCf-0z4zEmTuSAMdPY1kUdfb6Wct0PJmCgfYvqFkZQmvcG3bN-ty2_8&_nc_zt=23&_nc_ht=z-p3-scontent.fadd2-1.fna&_nc_gid=RZZ74LeVuQYjTb5RvKea2Q&oh=00_AfR5l4Tw5oiSqkiBYkCsrxPkoKrO6YqVgnDi0Sik-qwtuA&oe=688718DF" 
                      alt="Wolaita Soddo High School Students" 
                      className="rounded-lg w-full h-20 object-cover"
                      data-testid="school-gallery-students"
                    />
                    <img 
                      src="https://techreviewafrica.com/assets/images/news/2025/04/01/67ebedba31b1e1743515066.jpeg" 
                      alt="School Achievement Certificate" 
                      className="rounded-lg w-full h-20 object-cover"
                      data-testid="school-gallery-certificate"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
