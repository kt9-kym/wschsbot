import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Upload, Search, Filter, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import QuestionForm from "@/components/exam-questions/QuestionForm";
import QuestionList from "@/components/exam-questions/QuestionList";
import { type ExamQuestion } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ExamQuestionStats {
  stats: Array<{
    examType: string;
    subject: string;
    count: number;
  }>;
}

export default function ExamQuestions() {
  const [searchQuery, setSearchQuery] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("all");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: questionsData, isLoading } = useQuery<ExamQuestion[]>({
    queryKey: ['/api/exam-questions', subjectFilter !== 'all' ? subjectFilter : undefined, gradeFilter !== 'all' ? gradeFilter : undefined],
    queryFn: ({ queryKey }) => {
      const baseUrl = queryKey[0] as string;
      const subject = queryKey[1] as string | undefined;
      const grade = queryKey[2] as string | undefined;
      
      const params = new URLSearchParams();
      if (subject) params.append('subject', subject);
      if (grade) params.append('grade', grade);
      
      const url = params.toString() ? `${baseUrl}?${params.toString()}` : baseUrl;
      return fetch(url).then(res => res.json());
    }
  });

  const { data: stats } = useQuery<ExamQuestionStats>({
    queryKey: ['/api/exam-questions'],
  });

  const createQuestionMutation = useMutation({
    mutationFn: async (questionData: any) => {
      return await apiRequest('POST', '/api/exam-questions', questionData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/exam-questions'] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Exam question created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create exam question",
        variant: "destructive",
      });
    },
  });

  const bulkUploadMutation = useMutation({
    mutationFn: async (uploadData: { examType: string; grade: string; subject: string }) => {
      return await apiRequest('POST', '/api/exam-questions/bulk-upload', uploadData);
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/exam-questions'] });
      setIsBulkUploadOpen(false);
      toast({
        title: "Success",
        description: `${data.questions} questions uploaded successfully`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload questions",
        variant: "destructive",
      });
    },
  });

  const questions = Array.isArray(questionsData) ? questionsData : [];

  // Filter questions based on search query
  const filteredQuestions = questions.filter(question =>
    question.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    question.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group stats by exam type and subject
  const groupedStats = (stats?.stats || []).reduce((acc, item) => {
    if (!acc[item.examType]) acc[item.examType] = {};
    acc[item.examType][item.subject] = item.count;
    return acc;
  }, {} as Record<string, Record<string, number>>);

  const subjects = ['Mathematics', 'English', 'Biology', 'Chemistry', 'Physics', 'Geography', 'Civics'];

  const handleBulkUpload = (examType: string, grade: string, subject: string) => {
    bulkUploadMutation.mutate({ examType, grade, subject });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Ethiopian Exam Questions</h1>
                <p className="text-muted-foreground mt-1">
                  Manage EGSECE (Grade 10) and ESSLCE (Grade 12) exam question bank
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Dialog open={isBulkUploadOpen} onOpenChange={setIsBulkUploadOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" data-testid="bulk-upload-button">
                      <Upload className="w-4 h-4 mr-2" />
                      Bulk Upload
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Bulk Upload Ethiopian Exam Questions</DialogTitle>
                    </DialogHeader>
                    <BulkUploadForm 
                      onSubmit={handleBulkUpload}
                      isLoading={bulkUploadMutation.isPending}
                    />
                  </DialogContent>
                </Dialog>
                
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button data-testid="add-question-button">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Question
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Create New Exam Question</DialogTitle>
                    </DialogHeader>
                    <QuestionForm 
                      onSubmit={(data) => createQuestionMutation.mutate(data)}
                      isLoading={createQuestionMutation.isPending}
                    />
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Exam Type Tabs */}
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="egsece">EGSECE (Grade 10)</TabsTrigger>
                <TabsTrigger value="esslce">ESSLCE (Grade 12)</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                {/* Stats Overview */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <FileText className="w-5 h-5 text-primary" />
                        <span>EGSECE - Grade 10</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {Object.entries(groupedStats.EGSECE || {}).length === 0 ? (
                          <p className="text-muted-foreground">No questions uploaded yet</p>
                        ) : (
                          Object.entries(groupedStats.EGSECE || {}).map(([subject, count]) => (
                            <div key={subject} className="flex justify-between text-sm">
                              <span className="text-muted-foreground">{subject}:</span>
                              <span className="font-medium">{count} questions</span>
                            </div>
                          ))
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <FileText className="w-5 h-5 text-secondary" />
                        <span>ESSLCE - Grade 12</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {Object.entries(groupedStats.ESSLCE || {}).length === 0 ? (
                          <p className="text-muted-foreground">No questions uploaded yet</p>
                        ) : (
                          Object.entries(groupedStats.ESSLCE || {}).map(([subject, count]) => (
                            <div key={subject} className="flex justify-between text-sm">
                              <span className="text-muted-foreground">{subject}:</span>
                              <span className="font-medium">{count} questions</span>
                            </div>
                          ))
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="egsece" className="space-y-6">
                <QuestionTabContent 
                  grade="Grade 10"
                  examType="EGSECE"
                  questions={filteredQuestions.filter(q => q.grade === 'Grade 10')}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  subjectFilter={subjectFilter}
                  setSubjectFilter={setSubjectFilter}
                  subjects={subjects}
                  isLoading={isLoading}
                />
              </TabsContent>

              <TabsContent value="esslce" className="space-y-6">
                <QuestionTabContent 
                  grade="Grade 12"
                  examType="ESSLCE"
                  questions={filteredQuestions.filter(q => q.grade === 'Grade 12')}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  subjectFilter={subjectFilter}
                  setSubjectFilter={setSubjectFilter}
                  subjects={subjects}
                  isLoading={isLoading}
                />
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}

interface QuestionTabContentProps {
  grade: string;
  examType: string;
  questions: ExamQuestion[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  subjectFilter: string;
  setSubjectFilter: (filter: string) => void;
  subjects: string[];
  isLoading: boolean;
}

function QuestionTabContent({ 
  grade, 
  examType, 
  questions, 
  searchQuery, 
  setSearchQuery, 
  subjectFilter, 
  setSubjectFilter, 
  subjects,
  isLoading 
}: QuestionTabContentProps) {
  return (
    <>
      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-3" />
                <Input
                  placeholder="Search questions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="search-questions-input"
                />
              </div>
            </div>
            <Select value={subjectFilter} onValueChange={setSubjectFilter}>
              <SelectTrigger className="w-48" data-testid="subject-filter-select">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map(subject => (
                  <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Questions List */}
      <Card>
        <CardHeader>
          <CardTitle>
            {examType} Questions ({questions.length} questions)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <QuestionList questions={questions} isLoading={isLoading} />
        </CardContent>
      </Card>
    </>
  );
}

interface BulkUploadFormProps {
  onSubmit: (examType: string, grade: string, subject: string) => void;
  isLoading: boolean;
}

function BulkUploadForm({ onSubmit, isLoading }: BulkUploadFormProps) {
  const [examType, setExamType] = useState("");
  const [grade, setGrade] = useState("");
  const [subject, setSubject] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (examType && grade && subject) {
      onSubmit(examType, grade, subject);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm font-medium">Exam Type</label>
          <Select value={examType} onValueChange={setExamType}>
            <SelectTrigger data-testid="bulk-exam-type-select">
              <SelectValue placeholder="Select exam type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="EGSECE">EGSECE</SelectItem>
              <SelectItem value="ESSLCE">ESSLCE</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm font-medium">Grade</label>
          <Select value={grade} onValueChange={setGrade}>
            <SelectTrigger data-testid="bulk-grade-select">
              <SelectValue placeholder="Select grade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Grade 10">Grade 10</SelectItem>
              <SelectItem value="Grade 12">Grade 12</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <label className="text-sm font-medium">Subject</label>
        <Select value={subject} onValueChange={setSubject}>
          <SelectTrigger data-testid="bulk-subject-select">
            <SelectValue placeholder="Select subject" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Mathematics">Mathematics</SelectItem>
            <SelectItem value="English">English</SelectItem>
            <SelectItem value="Biology">Biology</SelectItem>
            <SelectItem value="Chemistry">Chemistry</SelectItem>
            <SelectItem value="Physics">Physics</SelectItem>
            <SelectItem value="Geography">Geography</SelectItem>
            <SelectItem value="Civics">Civics</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-muted/50 p-4 rounded-lg">
        <p className="text-sm text-muted-foreground">
          This will upload Ethiopian national exam questions from our curated question bank based on EAES materials and past exam papers.
        </p>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button 
          type="submit" 
          disabled={isLoading || !examType || !grade || !subject}
          data-testid="submit-bulk-upload-button"
        >
          {isLoading ? "Uploading..." : "Upload Questions"}
        </Button>
      </div>
    </form>
  );
}
