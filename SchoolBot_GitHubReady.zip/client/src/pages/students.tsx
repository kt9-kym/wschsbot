import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, Filter, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import StudentForm from "@/components/students/StudentForm";
import StudentTable from "@/components/students/StudentTable";
import { type Student } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Students() {
  const [searchQuery, setSearchQuery] = useState("");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: students = [], isLoading } = useQuery<Student[]>({
    queryKey: ['/api/students', gradeFilter !== 'all' ? gradeFilter : undefined],
    queryFn: ({ queryKey }) => {
      const baseUrl = queryKey[0] as string;
      const grade = queryKey[1] as string | undefined;
      const url = grade ? `${baseUrl}?grade=${encodeURIComponent(grade)}` : baseUrl;
      return fetch(url).then(res => res.json());
    }
  });

  const createStudentMutation = useMutation({
    mutationFn: async (studentData: any) => {
      return await apiRequest('POST', '/api/students', studentData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/students'] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Student registered successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to register student",
        variant: "destructive",
      });
    },
  });

  // Ensure students is always an array and filter based on search query
  const safeStudents = Array.isArray(students) ? students : [];
  const filteredStudents = safeStudents.filter(student =>
    student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.grade.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (student.section && student.section.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleExportData = () => {
    const csvData = [
      ['Name', 'Grade', 'Section', 'Stream', 'Telegram Username', 'Registration Date'],
      ...filteredStudents.map(student => [
        student.name,
        student.grade,
        student.section || '',
        student.stream || '',
        student.telegramUsername || '',
        new Date(student.registeredAt || '').toLocaleDateString()
      ])
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `students_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getGradeStats = () => {
    const stats = safeStudents.reduce((acc, student) => {
      acc[student.grade] = (acc[student.grade] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    return stats;
  };

  const gradeStats = getGradeStats();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Students Management</h1>
                <p className="text-muted-foreground mt-1">
                  Manage student registrations and bot users
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline" 
                  onClick={handleExportData}
                  data-testid="export-students-button"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export CSV
                </Button>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button data-testid="add-student-button">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Student
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Register New Student</DialogTitle>
                    </DialogHeader>
                    <StudentForm 
                      onSubmit={(data) => createStudentMutation.mutate(data)}
                      isLoading={createStudentMutation.isPending}
                    />
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{students.length}</p>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                  </div>
                </CardContent>
              </Card>
              {Object.entries(gradeStats).map(([grade, count]) => (
                <Card key={grade}>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-secondary">{count}</p>
                      <p className="text-sm text-muted-foreground">{grade}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Filters */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-3" />
                      <Input
                        placeholder="Search students by name, grade, or section..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                        data-testid="search-students-input"
                      />
                    </div>
                  </div>
                  <Select value={gradeFilter} onValueChange={setGradeFilter}>
                    <SelectTrigger className="w-48" data-testid="grade-filter-select">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Filter by grade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Grades</SelectItem>
                      <SelectItem value="Grade 9">Grade 9</SelectItem>
                      <SelectItem value="Grade 10">Grade 10</SelectItem>
                      <SelectItem value="Grade 11">Grade 11</SelectItem>
                      <SelectItem value="Grade 12">Grade 12</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Students Table */}
          <Card>
            <CardHeader>
              <CardTitle>
                Students List ({filteredStudents.length} of {students.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg animate-pulse">
                      <div className="w-12 h-12 bg-muted rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-muted rounded w-1/3"></div>
                        <div className="h-3 bg-muted rounded w-1/4"></div>
                      </div>
                      <div className="w-20 h-6 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              ) : filteredStudents.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-muted-foreground mb-4">
                    {searchQuery || gradeFilter !== 'all' ? 
                      'No students found matching your criteria' : 
                      'No students registered yet'
                    }
                  </div>
                  {(!searchQuery && gradeFilter === 'all') && (
                    <Button onClick={() => setIsDialogOpen(true)}>
                      Register First Student
                    </Button>
                  )}
                </div>
              ) : (
                <StudentTable students={filteredStudents} />
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
