# Overview

This is a Telegram bot management system for Wolaita Soddo Comprehensive High School (WSCHS) in Ethiopia. The application provides an administrative dashboard for managing students, teachers, exam questions, and Telegram bot interactions. It serves as a comprehensive educational platform where students can interact with a Telegram bot to access learning resources, ask AI-powered questions, receive homework assignments, and join study groups.

The system consists of a React-based admin dashboard and a Node.js/Express backend that handles Telegram bot webhooks, manages educational content, and provides analytics on student engagement.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on top of Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

The frontend follows a component-based architecture with separate page components for different admin functions (Dashboard, Students, Exam Questions, Bot Settings). The UI uses a consistent design system with reusable components stored in the `components/ui` directory.

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL
- **API Design**: RESTful API endpoints with Express router
- **File Structure**: Separation of concerns with dedicated service layers
- **Error Handling**: Centralized error handling middleware
- **Development**: Hot module replacement with Vite integration

The backend uses a layered architecture with:
- Route handlers in `server/routes.ts`
- Business logic in service classes (`telegramBot.ts`, `examQuestions.ts`, `openai.ts`)
- Data access layer in `storage.ts`
- Database schema definitions in `shared/schema.ts`

## Database Design
- **Primary Database**: PostgreSQL with Neon serverless connection
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Tables**: Users, Students, Teachers, ExamQuestions, Groups, Homework, Books, AiChats, BotAnalytics, SchoolInfo
- **Relationships**: Foreign key relationships between users and roles, students and groups
- **Data Types**: Comprehensive type safety with Drizzle Zod integration

The database schema supports multi-role access (students, teachers, admins) with proper normalization and indexing for performance.

## Authentication & Authorization
- **Admin Authentication**: Username/password based authentication for dashboard access
- **Telegram Integration**: Telegram user ID based identification for bot users
- **Role-Based Access**: Different permission levels for students, teachers, and administrators
- **Session Management**: Express session handling with PostgreSQL session store

## Telegram Bot Integration
- **Webhook Architecture**: Telegram webhooks processed through Express endpoints
- **Command Processing**: Structured command handling for student interactions
- **AI Integration**: OpenAI GPT integration for educational Q&A
- **Broadcasting**: Administrative message broadcasting to student groups
- **Analytics**: Comprehensive tracking of bot usage and student engagement

# External Dependencies

## Core Framework Dependencies
- **Database**: Neon PostgreSQL serverless database with connection pooling
- **ORM**: Drizzle ORM for type-safe database operations
- **UI Components**: Radix UI primitives for accessible component foundation
- **Styling**: Tailwind CSS for utility-first styling approach

## Telegram Integration
- **Telegram Bot API**: Direct HTTP requests to Telegram's REST API
- **Webhook Handling**: Express middleware for processing Telegram updates
- **Message Broadcasting**: Bulk message sending capabilities to student groups

## AI Services
- **OpenAI API**: GPT-5 model integration for educational question answering
- **Content Generation**: AI-powered quiz question generation
- **Educational Context**: Prompts tailored for Ethiopian high school curriculum

## Development Tools
- **Vite**: Fast development server and build tool with HMR
- **TypeScript**: Full type safety across frontend and backend
- **ESBuild**: Fast JavaScript bundling for production builds
- **Replit Integration**: Development environment optimization for Replit platform

## Validation & Forms
- **Zod**: Schema validation for forms and API data
- **React Hook Form**: Efficient form state management with validation
- **Type Safety**: End-to-end type safety from database to UI components

The application is designed to run in a Replit environment with automatic domain detection for webhook configuration and integrated development tooling.