import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { telegramBot } from "./services/telegramBot";
import { examQuestionsService } from "./services/examQuestions";
import { insertStudentSchema, insertExamQuestionSchema, insertHomeworkSchema, insertBookSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Telegram bot
  await telegramBot.initialize();
  
  // Webhook endpoint for Telegram
  app.post('/api/telegram/webhook', async (req, res) => {
    try {
      await telegramBot.handleUpdate(req.body);
      res.status(200).send('OK');
    } catch (error) {
      console.error('Telegram webhook error:', error);
      res.status(500).send('Error processing update');
    }
  });

  // Dashboard statistics
  app.get('/api/dashboard/stats', async (req, res) => {
    try {
      const totalStudents = await storage.getActiveStudentsCount();
      const aiQueries = await storage.getAiChatsCount();
      const examQuestionsStats = await storage.getExamQuestionsCount();
      
      const totalExamQuestions = examQuestionsStats.reduce((sum, stat) => sum + stat.count, 0);
      
      res.json({
        totalStudents,
        activeBotUsers: Math.floor(totalStudents * 0.8), // Approximate active users
        examQuestions: totalExamQuestions,
        aiQueries,
        examQuestionsBreakdown: examQuestionsStats
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({ message: 'Failed to fetch dashboard statistics' });
    }
  });

  // Recent activity
  app.get('/api/dashboard/activity', async (req, res) => {
    try {
      const recentChats = await storage.getRecentAiChats(5);
      const recentHomework = await storage.getRecentHomework(5);
      const analytics = await storage.getAnalytics(undefined, 1); // Last 24 hours
      
      const activity = [
        ...recentChats.map(chat => ({
          type: 'ai_question',
          description: `AI Question: "${chat.question.substring(0, 50)}..."`,
          timestamp: chat.createdAt,
          icon: 'ai'
        })),
        ...recentHomework.map(hw => ({
          type: 'homework',
          description: `Homework uploaded: ${hw.title}`,
          timestamp: hw.createdAt,
          icon: 'homework'
        })),
        ...analytics.slice(0, 10).map(event => ({
          type: event.eventType,
          description: getActivityDescription(event.eventType, event.data),
          timestamp: event.createdAt,
          icon: getActivityIcon(event.eventType)
        }))
      ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);

      res.json(activity);
    } catch (error) {
      console.error('Error fetching recent activity:', error);
      res.status(500).json({ message: 'Failed to fetch recent activity' });
    }
  });

  // Students endpoints
  app.get('/api/students', async (req, res) => {
    try {
      const { grade } = req.query;
      let students;
      
      if (grade) {
        students = await storage.getStudentsByGrade(grade as string);
      } else {
        // For now, get all students by fetching each grade
        const grades = ['Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'];
        const allStudents = await Promise.all(
          grades.map(g => storage.getStudentsByGrade(g))
        );
        students = allStudents.flat();
      }
      
      res.json(students);
    } catch (error) {
      console.error('Error fetching students:', error);
      res.status(500).json({ message: 'Failed to fetch students' });
    }
  });

  app.post('/api/students', async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      
      // Log analytics event
      await storage.createAnalyticsEvent({
        eventType: 'student_registered',
        userId: student.id,
        data: { grade: student.grade, section: student.section }
      });
      
      res.status(201).json(student);
    } catch (error) {
      console.error('Error creating student:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid student data', errors: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create student' });
      }
    }
  });

  // Exam questions endpoints
  app.get('/api/exam-questions', async (req, res) => {
    try {
      const { subject, grade } = req.query;
      
      if (subject && grade) {
        const questions = await storage.getExamQuestionsBySubject(subject as string, grade as string);
        res.json(questions);
      } else {
        const stats = await storage.getExamQuestionsCount();
        res.json({ stats });
      }
    } catch (error) {
      console.error('Error fetching exam questions:', error);
      res.status(500).json({ message: 'Failed to fetch exam questions' });
    }
  });

  app.post('/api/exam-questions', async (req, res) => {
    try {
      const validatedData = insertExamQuestionSchema.parse(req.body);
      const question = await storage.createExamQuestion(validatedData);
      res.status(201).json(question);
    } catch (error) {
      console.error('Error creating exam question:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid exam question data', errors: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create exam question' });
      }
    }
  });

  // Bulk upload exam questions from Ethiopian sources
  app.post('/api/exam-questions/bulk-upload', async (req, res) => {
    try {
      const { examType, grade, subject } = req.body;
      
      if (!examType || !grade || !subject) {
        return res.status(400).json({ message: 'Missing required fields: examType, grade, subject' });
      }

      const questions = await examQuestionsService.loadEthiopianExamQuestions(examType, grade, subject);
      
      const insertedQuestions = [];
      for (const question of questions) {
        try {
          const inserted = await storage.createExamQuestion({
            ...question,
            createdBy: req.body.createdBy || null
          });
          insertedQuestions.push(inserted);
        } catch (error) {
          console.error('Error inserting question:', error);
        }
      }

      res.json({ 
        message: `Successfully uploaded ${insertedQuestions.length} questions`,
        questions: insertedQuestions.length 
      });
    } catch (error) {
      console.error('Error bulk uploading questions:', error);
      res.status(500).json({ message: 'Failed to bulk upload questions' });
    }
  });

  // Random quiz endpoint
  app.get('/api/exam-questions/quiz', async (req, res) => {
    try {
      const { subject, grade, count = 5 } = req.query;
      
      if (!subject || !grade) {
        return res.status(400).json({ message: 'Subject and grade are required' });
      }

      const questions = await storage.getRandomExamQuestions(
        subject as string, 
        grade as string, 
        parseInt(count as string)
      );
      
      res.json(questions);
    } catch (error) {
      console.error('Error fetching quiz questions:', error);
      res.status(500).json({ message: 'Failed to fetch quiz questions' });
    }
  });

  // Homework endpoints
  app.get('/api/homework', async (req, res) => {
    try {
      const { grade } = req.query;
      
      if (grade) {
        const homework = await storage.getHomeworkByGrade(grade as string);
        res.json(homework);
      } else {
        const homework = await storage.getRecentHomework(20);
        res.json(homework);
      }
    } catch (error) {
      console.error('Error fetching homework:', error);
      res.status(500).json({ message: 'Failed to fetch homework' });
    }
  });

  app.post('/api/homework', async (req, res) => {
    try {
      const validatedData = insertHomeworkSchema.parse(req.body);
      const homework = await storage.createHomework(validatedData);
      
      // Broadcast to relevant groups
      await telegramBot.broadcastHomework(homework);
      
      res.status(201).json(homework);
    } catch (error) {
      console.error('Error creating homework:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid homework data', errors: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create homework' });
      }
    }
  });

  // Books endpoints
  app.get('/api/books', async (req, res) => {
    try {
      const { subject, grade } = req.query;
      
      if (subject && grade) {
        const books = await storage.getBooksBySubject(subject as string, grade as string);
        res.json(books);
      } else {
        res.status(400).json({ message: 'Subject and grade parameters are required' });
      }
    } catch (error) {
      console.error('Error fetching books:', error);
      res.status(500).json({ message: 'Failed to fetch books' });
    }
  });

  app.post('/api/books', async (req, res) => {
    try {
      const validatedData = insertBookSchema.parse(req.body);
      const book = await storage.createBook(validatedData);
      res.status(201).json(book);
    } catch (error) {
      console.error('Error creating book:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid book data', errors: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create book' });
      }
    }
  });

  // Groups endpoints
  app.get('/api/groups', async (req, res) => {
    try {
      const groups = await storage.getActiveGroups();
      res.json(groups);
    } catch (error) {
      console.error('Error fetching groups:', error);
      res.status(500).json({ message: 'Failed to fetch groups' });
    }
  });

  // School info endpoints
  app.get('/api/school-info', async (req, res) => {
    try {
      const schoolInfo = await storage.getAllSchoolInfo();
      res.json(schoolInfo);
    } catch (error) {
      console.error('Error fetching school info:', error);
      res.status(500).json({ message: 'Failed to fetch school information' });
    }
  });

  app.put('/api/school-info/:key', async (req, res) => {
    try {
      const { key } = req.params;
      const { value, updatedBy } = req.body;
      
      const info = await storage.updateSchoolInfo(key, value, updatedBy);
      res.json(info);
    } catch (error) {
      console.error('Error updating school info:', error);
      res.status(500).json({ message: 'Failed to update school information' });
    }
  });

  // Bot settings endpoints
  app.get('/api/bot/status', async (req, res) => {
    try {
      const status = await telegramBot.getStatus();
      res.json(status);
    } catch (error) {
      console.error('Error fetching bot status:', error);
      res.status(500).json({ message: 'Failed to fetch bot status' });
    }
  });

  app.post('/api/bot/broadcast', async (req, res) => {
    try {
      const { message, targetGrade, targetGroups } = req.body;
      
      const result = await telegramBot.broadcastMessage(message, { targetGrade, targetGroups });
      res.json(result);
    } catch (error) {
      console.error('Error broadcasting message:', error);
      res.status(500).json({ message: 'Failed to broadcast message' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getActivityDescription(eventType: string, data: any): string {
  switch (eventType) {
    case 'student_registered':
      return `New student registered: ${data?.grade || 'Unknown grade'}`;
    case 'ai_question':
      return `AI question asked`;
    case 'homework_request':
      return `Homework requested`;
    case 'quiz_started':
      return `Quiz started`;
    default:
      return `${eventType} event occurred`;
  }
}

function getActivityIcon(eventType: string): string {
  switch (eventType) {
    case 'student_registered':
      return 'user';
    case 'ai_question':
      return 'ai';
    case 'homework_request':
    case 'homework':
      return 'homework';
    case 'quiz_started':
      return 'quiz';
    default:
      return 'activity';
  }
}
