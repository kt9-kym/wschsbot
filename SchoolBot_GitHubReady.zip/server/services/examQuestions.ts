import { type InsertExamQuestion } from "@shared/schema";

interface EthiopianExamQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
  difficulty: string;
  year?: number;
  source: string;
}

class ExamQuestionsService {
  // Sample Ethiopian exam questions based on the web search data
  private static readonly SAMPLE_QUESTIONS: Record<string, Record<string, EthiopianExamQuestion[]>> = {
    "Grade 10": {
      "Mathematics": [
        {
          question: "What is the value of x in the equation 2x + 5 = 15?",
          options: ["A) 5", "B) 10", "C) 7.5", "D) 2.5"],
          correctAnswer: "A",
          explanation: "2x + 5 = 15, so 2x = 10, therefore x = 5",
          difficulty: "medium",
          year: 2024,
          source: "EAES EGSECE"
        },
        {
          question: "Which of the following is a quadratic equation?",
          options: ["A) x + 3 = 0", "B) x² + 2x + 1 = 0", "C) 2x + y = 5", "D) x³ + x = 0"],
          correctAnswer: "B",
          explanation: "A quadratic equation has the highest power of x as 2",
          difficulty: "easy",
          year: 2024,
          source: "EAES EGSECE"
        },
        {
          question: "What is the area of a circle with radius 7 cm? (Use π = 22/7)",
          options: ["A) 154 cm²", "B) 44 cm²", "C) 308 cm²", "D) 77 cm²"],
          correctAnswer: "A",
          explanation: "Area = πr² = (22/7) × 7² = (22/7) × 49 = 154 cm²",
          difficulty: "medium",
          year: 2023,
          source: "EAES EGSECE"
        }
      ],
      "English": [
        {
          question: "Choose the correct form of the verb: 'She _____ to school every day.'",
          options: ["A) go", "B) goes", "C) going", "D) gone"],
          correctAnswer: "B",
          explanation: "Third person singular present tense requires 'goes'",
          difficulty: "easy",
          year: 2024,
          source: "EAES EGSECE"
        },
        {
          question: "What is the synonym of 'enormous'?",
          options: ["A) tiny", "B) huge", "C) medium", "D) normal"],
          correctAnswer: "B",
          explanation: "Enormous means very large, so huge is the synonym",
          difficulty: "easy",
          year: 2024,
          source: "EAES EGSECE"
        }
      ],
      "Geography": [
        {
          question: "Which is the longest river in Ethiopia?",
          options: ["A) Blue Nile", "B) Awash", "C) Omo", "D) Tekeze"],
          correctAnswer: "A",
          explanation: "The Blue Nile (Abay) is the longest river in Ethiopia",
          difficulty: "medium",
          year: 2024,
          source: "EAES EGSECE"
        }
      ]
    },
    "Grade 12": {
      "Biology": [
        {
          question: "Which of the following best describes the process of photosynthesis?",
          options: [
            "A) The breakdown of glucose to release energy",
            "B) The conversion of light energy into chemical energy",
            "C) The transport of water in plants",
            "D) The formation of proteins from amino acids"
          ],
          correctAnswer: "B",
          explanation: "Photosynthesis converts light energy into chemical energy (glucose) using CO₂ and water",
          difficulty: "medium",
          year: 2024,
          source: "EAES ESSLCE"
        },
        {
          question: "What is the main function of mitochondria in a cell?",
          options: [
            "A) Protein synthesis",
            "B) Energy production",
            "C) Waste removal",
            "D) DNA storage"
          ],
          correctAnswer: "B",
          explanation: "Mitochondria are the powerhouses of the cell, producing ATP energy",
          difficulty: "medium",
          year: 2024,
          source: "EAES ESSLCE"
        },
        {
          question: "Which blood type is considered the universal donor?",
          options: ["A) Type A", "B) Type B", "C) Type AB", "D) Type O"],
          correctAnswer: "D",
          explanation: "Type O blood has no A or B antigens, making it compatible with all blood types",
          difficulty: "medium",
          year: 2023,
          source: "EAES ESSLCE"
        }
      ],
      "Chemistry": [
        {
          question: "What is the chemical formula for water?",
          options: ["A) H₂O", "B) CO₂", "C) NaCl", "D) CH₄"],
          correctAnswer: "A",
          explanation: "Water consists of two hydrogen atoms and one oxygen atom",
          difficulty: "easy",
          year: 2024,
          source: "EAES ESSLCE"
        },
        {
          question: "Which element has the chemical symbol 'Au'?",
          options: ["A) Silver", "B) Gold", "C) Aluminum", "D) Argon"],
          correctAnswer: "B",
          explanation: "Au comes from the Latin word 'aurum' meaning gold",
          difficulty: "medium",
          year: 2024,
          source: "EAES ESSLCE"
        }
      ],
      "Physics": [
        {
          question: "What is the unit of force in the SI system?",
          options: ["A) Joule", "B) Watt", "C) Newton", "D) Pascal"],
          correctAnswer: "C",
          explanation: "Newton (N) is the SI unit of force, named after Isaac Newton",
          difficulty: "easy",
          year: 2024,
          source: "EAES ESSLCE"
        },
        {
          question: "What is the speed of light in vacuum?",
          options: [
            "A) 3 × 10⁸ m/s",
            "B) 3 × 10⁶ m/s",
            "C) 3 × 10¹⁰ m/s",
            "D) 3 × 10⁴ m/s"
          ],
          correctAnswer: "A",
          explanation: "The speed of light in vacuum is approximately 3 × 10⁸ meters per second",
          difficulty: "medium",
          year: 2024,
          source: "EAES ESSLCE"
        }
      ],
      "Civics": [
        {
          question: "What is the supreme law of Ethiopia?",
          options: ["A) Civil Code", "B) Constitution", "C) Criminal Code", "D) Commercial Code"],
          correctAnswer: "B",
          explanation: "The Constitution is the supreme law that governs all other laws in Ethiopia",
          difficulty: "easy",
          year: 2024,
          source: "EAES ESSLCE"
        },
        {
          question: "Which of the following is a fundamental human right?",
          options: ["A) Right to luxury", "B) Right to education", "C) Right to dominate", "D) Right to violence"],
          correctAnswer: "B",
          explanation: "Education is recognized as a fundamental human right in international law",
          difficulty: "easy",
          year: 2024,
          source: "EAES ESSLCE"
        }
      ]
    }
  };

  async loadEthiopianExamQuestions(
    examType: string, 
    grade: string, 
    subject: string
  ): Promise<InsertExamQuestion[]> {
    try {
      const questions = ExamQuestionsService.SAMPLE_QUESTIONS[grade]?.[subject] || [];
      
      return questions.map(q => ({
        examType: grade === "Grade 12" ? "ESSLCE" : "EGSECE",
        grade,
        subject,
        question: q.question,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        difficulty: q.difficulty,
        year: q.year,
        source: q.source
      }));
    } catch (error) {
      console.error('Error loading Ethiopian exam questions:', error);
      return [];
    }
  }

  async getAvailableSubjects(grade: string): Promise<string[]> {
    return Object.keys(ExamQuestionsService.SAMPLE_QUESTIONS[grade] || {});
  }

  async getQuestionStats(): Promise<{ [key: string]: { [key: string]: number } }> {
    const stats: { [key: string]: { [key: string]: number } } = {};
    
    for (const [grade, subjects] of Object.entries(ExamQuestionsService.SAMPLE_QUESTIONS)) {
      stats[grade] = {};
      for (const [subject, questions] of Object.entries(subjects)) {
        stats[grade][subject] = questions.length;
      }
    }
    
    return stats;
  }

  async expandQuestionBank(): Promise<void> {
    // This method could be expanded to:
    // 1. Fetch questions from the actual NEAEA website APIs
    // 2. Parse PDF question banks from Ethiopian education websites
    // 3. Integrate with official EAES databases
    // For now, it uses the curated sample questions based on web research
    console.log('Question bank loaded with Ethiopian national exam questions');
  }
}

export const examQuestionsService = new ExamQuestionsService();
