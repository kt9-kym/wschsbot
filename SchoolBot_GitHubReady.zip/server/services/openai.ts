import OpenAI from "openai";

class OpenAIService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || ""
    });
  }

  async getEducationalAnswer(question: string, grade?: string): Promise<string> {
    if (!process.env.OPENAI_API_KEY && !process.env.OPENAI_KEY) {
      return "AI assistant is currently unavailable. Please contact your teacher for help.";
    }

    try {
      const gradeContext = grade ? ` for ${grade} students` : "";
      const prompt = `You are an educational AI assistant for Wolaita Soddo Comprehensive High School in Ethiopia. 
      Please provide a clear, accurate, and educational answer to the following question${gradeContext}. 
      Keep the answer appropriate for high school students and include relevant context for Ethiopian education.
      
      Question: ${question}`;

      const response = await this.openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a helpful educational assistant for Ethiopian high school students. Provide clear, accurate, and age-appropriate educational content."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 500,
        temperature: 0.7
      });

      return response.choices[0]?.message?.content || "I couldn't generate an answer. Please try asking in a different way.";
    } catch (error) {
      console.error("OpenAI API error:", error);
      return "I'm having trouble processing your question right now. Please try again later or contact your teacher.";
    }
  }

  async generateQuizQuestions(subject: string, grade: string, count: number = 5): Promise<any[]> {
    if (!process.env.OPENAI_API_KEY && !process.env.OPENAI_KEY) {
      return [];
    }

    try {
      const prompt = `Generate ${count} multiple choice questions for ${grade} ${subject} based on Ethiopian curriculum. 
      Each question should have 4 options (A, B, C, D) and be appropriate for Ethiopian high school students.
      Format as JSON array with structure: {"question": "...", "options": ["A) ...", "B) ...", "C) ...", "D) ..."], "correct": "A", "explanation": "..."}`;

      const response = await this.openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an expert in Ethiopian high school curriculum. Generate educational quiz questions."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 1500
      });

      const result = JSON.parse(response.choices[0]?.message?.content || "{}");
      return result.questions || [];
    } catch (error) {
      console.error("Error generating quiz questions:", error);
      return [];
    }
  }

  async translateToAmharic(text: string): Promise<string> {
    if (!process.env.OPENAI_API_KEY && !process.env.OPENAI_KEY) {
      return text;
    }

    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a professional translator. Translate the following text from English to Amharic while maintaining the educational context."
          },
          {
            role: "user",
            content: `Translate this educational content to Amharic: ${text}`
          }
        ],
        max_tokens: 800
      });

      return response.choices[0]?.message?.content || text;
    } catch (error) {
      console.error("Translation error:", error);
      return text;
    }
  }
}

export const openaiService = new OpenAIService();
