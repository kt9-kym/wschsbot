import { storage } from "../storage";
import { openaiService } from "./openai";

interface TelegramUpdate {
  message?: {
    message_id: number;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      last_name?: string;
      username?: string;
    };
    chat: {
      id: number;
      type: string;
    };
    date: number;
    text?: string;
  };
}

interface BroadcastOptions {
  targetGrade?: string;
  targetGroups?: string[];
}

class TelegramBotService {
  private botToken: string;
  private webhookUrl: string;
  private adminId: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || process.env.TELEGRAM_TOKEN || "";
    this.adminId = process.env.TELEGRAM_ADMIN_ID || "5622386935";
    
    // Use REPLIT_DOMAINS for webhook URL
    const domains = process.env.REPLIT_DOMAINS?.split(',') || ['localhost:5000'];
    this.webhookUrl = `https://${domains[0]}/api/telegram/webhook`;
  }

  async initialize(): Promise<void> {
    if (!this.botToken) {
      console.warn('Telegram bot token not provided. Bot will not function.');
      return;
    }

    try {
      // Set webhook
      await this.setWebhook();
      
      // Initialize school info if not exists
      await this.initializeSchoolInfo();
      
      console.log('Telegram bot initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Telegram bot:', error);
    }
  }

  private async setWebhook(): Promise<void> {
    const url = `https://api.telegram.org/bot${this.botToken}/setWebhook`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: this.webhookUrl })
    });

    if (!response.ok) {
      throw new Error(`Failed to set webhook: ${response.statusText}`);
    }
  }

  private async initializeSchoolInfo(): Promise<void> {
    const schoolInfoData = [
      { key: 'school_name', value: 'Wolaita Soddo Comprehensive High School' },
      { key: 'vision', value: 'To nurture responsible citizens and future leaders through holistic education.' },
      { key: 'mission', value: 'To provide a safe, inclusive, and innovative learning environment that empowers every student to reach their full potential.' },
      { key: 'values', value: 'Integrity, Excellence, Respect, Collaboration, and Service' },
      { key: 'location', value: 'Soddo Town, Southern Ethiopia' },
      { key: 'languages', value: 'English & Amharic' }
    ];

    for (const info of schoolInfoData) {
      const existing = await storage.getSchoolInfo(info.key);
      if (!existing) {
        await storage.updateSchoolInfo(info.key, info.value, 'system');
      }
    }
  }

  async handleUpdate(update: TelegramUpdate): Promise<void> {
    if (!update.message) return;

    const { message } = update;
    const chatId = message.chat.id.toString();
    const userId = message.from.id.toString();
    const text = message.text?.trim() || "";
    const userName = `${message.from.first_name} ${message.from.last_name || ''}`.trim();

    try {
      // Log analytics
      await storage.createAnalyticsEvent({
        eventType: 'message_received',
        userId,
        data: { chatId, command: text.split(' ')[0] }
      });

      // Check if user is a student
      let student = await storage.getStudentByTelegramId(userId);

      // Handle commands
      if (text.startsWith('/start')) {
        await this.handleStartCommand(chatId, student);
      } else if (text.startsWith('/help')) {
        await this.handleHelpCommand(chatId, userName);
      } else if (text.startsWith('/homework')) {
        await this.handleHomeworkCommand(chatId, student);
      } else if (text.startsWith('/quiz')) {
        await this.handleQuizCommand(chatId, student);
      } else if (text.startsWith('/ask')) {
        await this.handleAskCommand(chatId, text, student);
      } else if (text.startsWith('/books')) {
        await this.handleBooksCommand(chatId, student);
      } else if (text.startsWith('/groups')) {
        await this.handleGroupsCommand(chatId);
      } else if (text.startsWith('/location')) {
        await this.handleLocationCommand(chatId);
      } else if (text.startsWith('/info')) {
        await this.handleSchoolInfoCommand(chatId);
      } else if (this.isRegistrationText(text)) {
        await this.handleRegistration(chatId, userId, userName, text);
      } else {
        await this.handleUnknownCommand(chatId);
      }

      // Update student last active time
      if (student) {
        await storage.updateStudent(student.id, { lastActiveAt: new Date() });
      }

    } catch (error) {
      console.error('Error handling Telegram update:', error);
      await this.sendMessage(chatId, "❌ Sorry, something went wrong. Please try again later.");
    }
  }

  private async handleStartCommand(chatId: string, student: any): Promise<void> {
    const schoolInfo = await storage.getSchoolInfo('school_name');
    const schoolName = schoolInfo?.value || 'Wolaita Soddo Comprehensive High School';

    const welcomeMessage = `👋 Welcome to ${schoolName} Bot!\n\n` +
      `🎓 I'm here to help you with:\n` +
      `• 📝 Homework assignments\n` +
      `• 📊 Practice quizzes\n` +
      `• 🤖 AI-powered Q&A assistance\n` +
      `• 📚 Books and resources\n` +
      `• 👥 Study groups\n` +
      `• ℹ️ School information\n\n` +
      (student ? 
        `Welcome back, ${student.name}! Use the commands below:` :
        `Please register by sending your name and grade:\n` +
        `Example: "Kaleab Tadesse Grade 10"`
      ) + 
      `\n\n📋 Available Commands:\n` +
      `• /homework - View assignments\n` +
      `• /quiz - Take practice quiz\n` +
      `• /ask <question> - Ask AI assistant\n` +
      `• /books - Access study materials\n` +
      `• /groups - Join study groups\n` +
      `• /info - School information\n` +
      `• /help - Get assistance`;

    await this.sendMessage(chatId, welcomeMessage);
  }

  private async handleHelpCommand(chatId: string, userName: string): Promise<void> {
    await this.sendMessage(chatId, "📩 Your help request has been sent to our admin team. They will respond soon!");
    
    // Notify admin
    await this.sendMessage(this.adminId, `📞 Help request from ${userName} (ID: ${chatId})`);
  }

  private async handleHomeworkCommand(chatId: string, student: any): Promise<void> {
    if (!student) {
      await this.sendMessage(chatId, "⚠️ Please register first by sending your name and grade (e.g., 'Kaleab Tadesse Grade 10')");
      return;
    }

    const homework = await storage.getHomeworkByGrade(student.grade);
    
    if (homework.length === 0) {
      await this.sendMessage(chatId, `📝 No homework assignments found for ${student.grade}.`);
      return;
    }

    let message = `📝 Homework for ${student.grade}:\n\n`;
    homework.slice(0, 5).forEach((hw, index) => {
      message += `${index + 1}. *${hw.title}*\n`;
      message += `   Subject: ${hw.subject}\n`;
      if (hw.dueDate) {
        message += `   Due: ${new Date(hw.dueDate).toLocaleDateString()}\n`;
      }
      if (hw.description) {
        message += `   ${hw.description.substring(0, 100)}...\n`;
      }
      message += '\n';
    });

    await this.sendMessage(chatId, message, 'Markdown');
    
    // Log analytics
    await storage.createAnalyticsEvent({
      eventType: 'homework_request',
      userId: student.id,
      data: { grade: student.grade }
    });
  }

  private async handleQuizCommand(chatId: string, student: any): Promise<void> {
    if (!student) {
      await this.sendMessage(chatId, "⚠️ Please register first by sending your name and grade (e.g., 'Kaleab Tadesse Grade 10')");
      return;
    }

    // Get random quiz questions for the student's grade
    const subjects = student.grade === 'Grade 12' ? 
      ['Biology', 'Chemistry', 'Physics', 'Mathematics'] :
      ['Mathematics', 'English', 'Science', 'Geography'];

    const randomSubject = subjects[Math.floor(Math.random() * subjects.length)];
    const questions = await storage.getRandomExamQuestions(randomSubject, student.grade, 1);

    if (questions.length === 0) {
      await this.sendMessage(chatId, `📚 No quiz questions available for ${student.grade} ${randomSubject}. Check back later!`);
      return;
    }

    const question = questions[0];
    const options = Array.isArray(question.options) ? question.options : JSON.parse(question.options as string);
    
    let quizMessage = `📊 *Quiz Time - ${randomSubject}*\n\n`;
    quizMessage += `*Question:* ${question.question}\n\n`;
    
    options.forEach((option: string, index: number) => {
      quizMessage += `${String.fromCharCode(65 + index)}) ${option}\n`;
    });
    
    quizMessage += `\n💡 Think about your answer and reply with the letter (A, B, C, or D)`;

    await this.sendMessage(chatId, quizMessage, 'Markdown');
    
    // Log analytics
    await storage.createAnalyticsEvent({
      eventType: 'quiz_started',
      userId: student.id,
      data: { subject: randomSubject, grade: student.grade, questionId: question.id }
    });
  }

  private async handleAskCommand(chatId: string, text: string, student: any): Promise<void> {
    const question = text.replace('/ask', '').trim();
    
    if (!question) {
      await this.sendMessage(chatId, "❓ Please ask a question after /ask\nExample: /ask What is photosynthesis?");
      return;
    }

    await this.sendMessage(chatId, "🤖 Thinking... Please wait a moment.");

    try {
      const answer = await openaiService.getEducationalAnswer(question, student?.grade);
      const responseMessage = `🤖 *AI Assistant Answer:*\n\n${answer}\n\n` +
        `📚 This answer is provided by AI. For complex topics, please consult your teachers.\n\n` +
        `_Bot created by the WSCHS Tech Team_`;

      await this.sendMessage(chatId, responseMessage, 'Markdown');

      // Save AI chat log
      if (student) {
        await storage.createAiChat({
          studentId: student.id,
          question,
          answer,
          language: 'en'
        });
      }

      // Log analytics
      await storage.createAnalyticsEvent({
        eventType: 'ai_question',
        userId: student?.id || chatId,
        data: { question: question.substring(0, 100) }
      });

    } catch (error) {
      console.error('AI service error:', error);
      await this.sendMessage(chatId, "⚠️ Sorry, the AI assistant is currently unavailable. Please try again later or contact a teacher.");
    }
  }

  private async handleBooksCommand(chatId: string, student: any): Promise<void> {
    if (!student) {
      await this.sendMessage(chatId, "⚠️ Please register first by sending your name and grade (e.g., 'Kaleab Tadesse Grade 10')");
      return;
    }

    // For demonstration, show available subjects for the grade
    const subjects = student.grade === 'Grade 12' ? 
      ['Biology', 'Chemistry', 'Physics', 'Mathematics', 'English', 'Civics'] :
      ['Mathematics', 'English', 'Science', 'Geography', 'History'];

    let message = `📚 *Books & Resources for ${student.grade}*\n\n`;
    message += `📖 Available subjects:\n`;
    subjects.forEach((subject, index) => {
      message += `${index + 1}. ${subject}\n`;
    });
    
    message += `\n💡 To access books for a specific subject, contact your teacher or visit the school library.\n\n`;
    message += `🌐 Additional resources:\n`;
    message += `• Ethiopian National Exam questions\n`;
    message += `• Practice worksheets\n`;
    message += `• Reference materials`;

    await this.sendMessage(chatId, message, 'Markdown');
  }

  private async handleGroupsCommand(chatId: string): Promise<void> {
    const groups = await storage.getActiveGroups();
    
    let message = `👥 *Study Groups*\n\n`;
    
    if (groups.length === 0) {
      message += `No active study groups found. Contact your teachers to create new groups.`;
    } else {
      message += `📚 Available study groups:\n\n`;
      groups.forEach((group, index) => {
        message += `${index + 1}. *${group.name}*\n`;
        if (group.grade) message += `   Grade: ${group.grade}\n`;
        if (group.subject) message += `   Subject: ${group.subject}\n`;
        if (group.inviteLink) message += `   Join: ${group.inviteLink}\n`;
        message += '\n';
      });
    }

    await this.sendMessage(chatId, message, 'Markdown');
  }

  private async handleLocationCommand(chatId: string): Promise<void> {
    const locationInfo = await storage.getSchoolInfo('location');
    const location = locationInfo?.value || 'Soddo Town, Southern Ethiopia';
    
    const message = `📍 *Wolaita Soddo Comprehensive High School*\n\n` +
      `🏫 Location: ${location}\n\n` +
      `🌍 We are located in the heart of Soddo Town, serving the educational needs of our community.\n\n` +
      `📞 For directions or more information, please contact the school administration.`;

    await this.sendMessage(chatId, message, 'Markdown');
  }

  private async handleSchoolInfoCommand(chatId: string): Promise<void> {
    const schoolName = (await storage.getSchoolInfo('school_name'))?.value || 'Wolaita Soddo Comprehensive High School';
    const vision = (await storage.getSchoolInfo('vision'))?.value || '';
    const mission = (await storage.getSchoolInfo('mission'))?.value || '';
    const values = (await storage.getSchoolInfo('values'))?.value || '';
    const languages = (await storage.getSchoolInfo('languages'))?.value || 'English & Amharic';

    let message = `🏫 *${schoolName}*\n\n`;
    
    if (vision) {
      message += `🎯 *Vision:*\n${vision}\n\n`;
    }
    
    if (mission) {
      message += `🎯 *Mission:*\n${mission}\n\n`;
    }
    
    if (values) {
      message += `⭐ *Core Values:*\n${values}\n\n`;
    }
    
    message += `🗣️ *Languages of Instruction:* ${languages}\n\n`;
    message += `🌟 Our school is committed to providing quality education and nurturing future leaders.`;

    await this.sendMessage(chatId, message, 'Markdown');
  }

  private isRegistrationText(text: string): boolean {
    // Check if text contains grade pattern
    return /grade\s*(9|10|11|12)/i.test(text) && text.split(' ').length >= 2;
  }

  private async handleRegistration(chatId: string, userId: string, userName: string, text: string): Promise<void> {
    try {
      // Parse registration text
      const words = text.split(' ');
      const gradeMatch = text.match(/grade\s*(9|10|11|12)/i);
      
      if (!gradeMatch) {
        await this.sendMessage(chatId, "❌ Please specify your grade (9, 10, 11, or 12)\nExample: 'Kaleab Tadesse Grade 10'");
        return;
      }

      const grade = `Grade ${gradeMatch[1]}`;
      const nameWords = words.filter(word => !word.toLowerCase().includes('grade') && !word.match(/^(9|10|11|12)$/));
      const name = nameWords.join(' ').trim() || userName;

      // Check if student already exists
      const existingStudent = await storage.getStudentByTelegramId(userId);
      if (existingStudent) {
        await this.sendMessage(chatId, `✅ You are already registered as ${existingStudent.name} (${existingStudent.grade})`);
        return;
      }

      // Create new student
      const student = await storage.createStudent({
        telegramId: userId,
        name,
        grade,
        isActive: true
      });

      // Log analytics
      await storage.createAnalyticsEvent({
        eventType: 'student_registered',
        userId: student.id,
        data: { grade, name }
      });

      const welcomeMessage = `✅ *Registration Successful!*\n\n` +
        `👤 Name: ${name}\n` +
        `🎓 Grade: ${grade}\n\n` +
        `🎉 Welcome to WSCHS Bot! You can now:\n` +
        `• Check homework with /homework\n` +
        `• Take quizzes with /quiz\n` +
        `• Ask questions with /ask\n` +
        `• Access books with /books\n` +
        `• Join groups with /groups\n\n` +
        `📚 Happy learning!`;

      await this.sendMessage(chatId, welcomeMessage, 'Markdown');

    } catch (error) {
      console.error('Registration error:', error);
      await this.sendMessage(chatId, "❌ Registration failed. Please try again or contact support.");
    }
  }

  private async handleUnknownCommand(chatId: string): Promise<void> {
    const message = `❓ *Unknown command*\n\n` +
      `📋 Available commands:\n` +
      `• /start - Welcome message\n` +
      `• /homework - View assignments\n` +
      `• /quiz - Take practice quiz\n` +
      `• /ask <question> - Ask AI assistant\n` +
      `• /books - Access study materials\n` +
      `• /groups - Join study groups\n` +
      `• /info - School information\n` +
      `• /help - Get assistance\n\n` +
      `💡 To register, send: "Your Name Grade X" (e.g., "Kaleab Tadesse Grade 10")`;

    await this.sendMessage(chatId, message, 'Markdown');
  }

  async sendMessage(chatId: string, text: string, parseMode: string = 'HTML'): Promise<void> {
    if (!this.botToken) return;

    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: parseMode
        })
      });

      if (!response.ok) {
        console.error('Failed to send message:', await response.text());
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  }

  async broadcastMessage(message: string, options: BroadcastOptions = {}): Promise<{ success: number; failed: number }> {
    const groups = await storage.getActiveGroups();
    const targetGroups = options.targetGroups || [];
    const targetGrade = options.targetGrade;

    let filteredGroups = groups;
    
    if (targetGrade) {
      filteredGroups = filteredGroups.filter(group => group.grade === targetGrade);
    }
    
    if (targetGroups.length > 0) {
      filteredGroups = filteredGroups.filter(group => targetGroups.includes(group.id));
    }

    let success = 0;
    let failed = 0;

    for (const group of filteredGroups) {
      if (group.telegramGroupId) {
        try {
          await this.sendMessage(group.telegramGroupId, message);
          success++;
        } catch (error) {
          console.error(`Failed to send to group ${group.name}:`, error);
          failed++;
        }
      }
    }

    return { success, failed };
  }

  async broadcastHomework(homework: any): Promise<void> {
    const message = `📝 *New Homework Assignment*\n\n` +
      `📚 Subject: ${homework.subject}\n` +
      `🎓 Grade: ${homework.grade}\n` +
      `📋 Title: ${homework.title}\n\n` +
      (homework.description ? `📄 Description:\n${homework.description}\n\n` : '') +
      (homework.dueDate ? `⏰ Due Date: ${new Date(homework.dueDate).toLocaleDateString()}\n\n` : '') +
      `💡 Use /homework command to view all assignments.`;

    await this.broadcastMessage(message, { targetGrade: homework.grade });
  }

  async getStatus(): Promise<any> {
    if (!this.botToken) {
      return { status: 'inactive', message: 'Bot token not configured' };
    }

    try {
      const url = `https://api.telegram.org/bot${this.botToken}/getMe`;
      const response = await fetch(url);
      
      if (response.ok) {
        const data = await response.json();
        return {
          status: 'active',
          botInfo: data.result,
          webhookUrl: this.webhookUrl
        };
      } else {
        return { status: 'error', message: 'Failed to connect to Telegram API' };
      }
    } catch (error) {
      return { status: 'error', message: error.message };
    }
  }
}

export const telegramBot = new TelegramBotService();
