import { 
  users, students, teachers, examQuestions, groups, homework, books, aiChats, botAnalytics, schoolInfo,
  type User, type InsertUser, type Student, type InsertStudent, type Teacher, type InsertTeacher,
  type ExamQuestion, type InsertExamQuestion, type Group, type InsertGroup,
  type Homework, type InsertHomework, type Book, type InsertBook,
  type AiChat, type BotAnalytics, type SchoolInfo
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, like, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Student operations
  getStudent(id: string): Promise<Student | undefined>;
  getStudentByTelegramId(telegramId: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, updates: Partial<Student>): Promise<Student>;
  getStudentsByGrade(grade: string): Promise<Student[]>;
  getActiveStudentsCount(): Promise<number>;
  
  // Teacher operations
  getTeacher(id: string): Promise<Teacher | undefined>;
  getTeacherByTelegramId(telegramId: string): Promise<Teacher | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  getTeachers(): Promise<Teacher[]>;
  
  // Exam questions operations
  getExamQuestion(id: string): Promise<ExamQuestion | undefined>;
  createExamQuestion(question: InsertExamQuestion): Promise<ExamQuestion>;
  getExamQuestionsBySubject(subject: string, grade: string): Promise<ExamQuestion[]>;
  getRandomExamQuestions(subject: string, grade: string, limit: number): Promise<ExamQuestion[]>;
  getExamQuestionsCount(): Promise<{ examType: string; subject: string; count: number }[]>;
  
  // Group operations
  getGroup(id: string): Promise<Group | undefined>;
  createGroup(group: InsertGroup): Promise<Group>;
  getActiveGroups(): Promise<Group[]>;
  getGroupsByGrade(grade: string): Promise<Group[]>;
  
  // Homework operations
  getHomework(id: string): Promise<Homework | undefined>;
  createHomework(homework: InsertHomework): Promise<Homework>;
  getHomeworkByGrade(grade: string): Promise<Homework[]>;
  getRecentHomework(limit?: number): Promise<Homework[]>;
  
  // Books operations
  getBook(id: string): Promise<Book | undefined>;
  createBook(book: InsertBook): Promise<Book>;
  getBooksBySubject(subject: string, grade: string): Promise<Book[]>;
  
  // AI Chat operations
  createAiChat(chat: { studentId: string; question: string; answer: string; language?: string }): Promise<AiChat>;
  getRecentAiChats(limit?: number): Promise<AiChat[]>;
  getAiChatsCount(): Promise<number>;
  
  // Analytics operations
  createAnalyticsEvent(event: { eventType: string; userId?: string; data?: any }): Promise<BotAnalytics>;
  getAnalytics(eventType?: string, days?: number): Promise<BotAnalytics[]>;
  
  // School info operations
  getSchoolInfo(key: string): Promise<SchoolInfo | undefined>;
  updateSchoolInfo(key: string, value: string, updatedBy: string): Promise<SchoolInfo>;
  getAllSchoolInfo(): Promise<SchoolInfo[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Student operations
  async getStudent(id: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async getStudentByTelegramId(telegramId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.telegramId, telegramId));
    return student;
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const [student] = await db.insert(students).values(insertStudent).returning();
    return student;
  }

  async updateStudent(id: string, updates: Partial<Student>): Promise<Student> {
    const [student] = await db
      .update(students)
      .set({ ...updates, lastActiveAt: new Date() })
      .where(eq(students.id, id))
      .returning();
    return student;
  }

  async getStudentsByGrade(grade: string): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.grade, grade));
  }

  async getActiveStudentsCount(): Promise<number> {
    const result = await db
      .select({ count: count() })
      .from(students)
      .where(eq(students.isActive, true));
    return result[0].count;
  }

  // Teacher operations
  async getTeacher(id: string): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher;
  }

  async getTeacherByTelegramId(telegramId: string): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.telegramId, telegramId));
    return teacher;
  }

  async createTeacher(insertTeacher: InsertTeacher): Promise<Teacher> {
    const [teacher] = await db.insert(teachers).values(insertTeacher).returning();
    return teacher;
  }

  async getTeachers(): Promise<Teacher[]> {
    return await db.select().from(teachers).where(eq(teachers.isActive, true));
  }

  // Exam questions operations
  async getExamQuestion(id: string): Promise<ExamQuestion | undefined> {
    const [question] = await db.select().from(examQuestions).where(eq(examQuestions.id, id));
    return question;
  }

  async createExamQuestion(insertQuestion: InsertExamQuestion): Promise<ExamQuestion> {
    const [question] = await db.insert(examQuestions).values(insertQuestion).returning();
    return question;
  }

  async getExamQuestionsBySubject(subject: string, grade: string): Promise<ExamQuestion[]> {
    return await db
      .select()
      .from(examQuestions)
      .where(and(eq(examQuestions.subject, subject), eq(examQuestions.grade, grade)));
  }

  async getRandomExamQuestions(subject: string, grade: string, limit: number): Promise<ExamQuestion[]> {
    return await db
      .select()
      .from(examQuestions)
      .where(and(eq(examQuestions.subject, subject), eq(examQuestions.grade, grade)))
      .orderBy(sql`RANDOM()`)
      .limit(limit);
  }

  async getExamQuestionsCount(): Promise<{ examType: string; subject: string; count: number }[]> {
    return await db
      .select({
        examType: examQuestions.examType,
        subject: examQuestions.subject,
        count: count()
      })
      .from(examQuestions)
      .groupBy(examQuestions.examType, examQuestions.subject);
  }

  // Group operations
  async getGroup(id: string): Promise<Group | undefined> {
    const [group] = await db.select().from(groups).where(eq(groups.id, id));
    return group;
  }

  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const [group] = await db.insert(groups).values(insertGroup).returning();
    return group;
  }

  async getActiveGroups(): Promise<Group[]> {
    return await db.select().from(groups).where(eq(groups.isActive, true));
  }

  async getGroupsByGrade(grade: string): Promise<Group[]> {
    return await db.select().from(groups).where(and(eq(groups.grade, grade), eq(groups.isActive, true)));
  }

  // Homework operations
  async getHomework(id: string): Promise<Homework | undefined> {
    const [hw] = await db.select().from(homework).where(eq(homework.id, id));
    return hw;
  }

  async createHomework(insertHomework: InsertHomework): Promise<Homework> {
    const [hw] = await db.insert(homework).values(insertHomework).returning();
    return hw;
  }

  async getHomeworkByGrade(grade: string): Promise<Homework[]> {
    return await db.select().from(homework).where(eq(homework.grade, grade)).orderBy(desc(homework.createdAt));
  }

  async getRecentHomework(limit: number = 10): Promise<Homework[]> {
    return await db.select().from(homework).orderBy(desc(homework.createdAt)).limit(limit);
  }

  // Books operations
  async getBook(id: string): Promise<Book | undefined> {
    const [book] = await db.select().from(books).where(eq(books.id, id));
    return book;
  }

  async createBook(insertBook: InsertBook): Promise<Book> {
    const [book] = await db.insert(books).values(insertBook).returning();
    return book;
  }

  async getBooksBySubject(subject: string, grade: string): Promise<Book[]> {
    return await db
      .select()
      .from(books)
      .where(and(eq(books.subject, subject), eq(books.grade, grade)));
  }

  // AI Chat operations
  async createAiChat(chat: { studentId: string; question: string; answer: string; language?: string }): Promise<AiChat> {
    const [aiChat] = await db.insert(aiChats).values(chat).returning();
    return aiChat;
  }

  async getRecentAiChats(limit: number = 10): Promise<AiChat[]> {
    return await db.select().from(aiChats).orderBy(desc(aiChats.createdAt)).limit(limit);
  }

  async getAiChatsCount(): Promise<number> {
    const result = await db.select({ count: count() }).from(aiChats);
    return result[0].count;
  }

  // Analytics operations
  async createAnalyticsEvent(event: { eventType: string; userId?: string; data?: any }): Promise<BotAnalytics> {
    const [analytics] = await db.insert(botAnalytics).values(event).returning();
    return analytics;
  }

  async getAnalytics(eventType?: string, days: number = 30): Promise<BotAnalytics[]> {
    let query = db.select().from(botAnalytics);
    
    if (eventType) {
      query = query.where(
        and(
          eq(botAnalytics.eventType, eventType),
          sql`${botAnalytics.createdAt} >= NOW() - INTERVAL ${days} DAY`
        )
      );
    } else {
      query = query.where(sql`${botAnalytics.createdAt} >= NOW() - INTERVAL ${days} DAY`);
    }

    return await query.orderBy(desc(botAnalytics.createdAt));
  }

  // School info operations
  async getSchoolInfo(key: string): Promise<SchoolInfo | undefined> {
    const [info] = await db.select().from(schoolInfo).where(eq(schoolInfo.key, key));
    return info;
  }

  async updateSchoolInfo(key: string, value: string, updatedBy: string): Promise<SchoolInfo> {
    const [info] = await db
      .insert(schoolInfo)
      .values({ key, value, updatedBy })
      .onConflictDoUpdate({
        target: schoolInfo.key,
        set: { value, updatedBy, updatedAt: new Date() }
      })
      .returning();
    return info;
  }

  async getAllSchoolInfo(): Promise<SchoolInfo[]> {
    return await db.select().from(schoolInfo);
  }
}

export const storage = new DatabaseStorage();
