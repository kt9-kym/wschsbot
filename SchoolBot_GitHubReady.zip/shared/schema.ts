import { sql, relations } from "drizzle-orm";
import { 
  pgTable, 
  text, 
  varchar, 
  integer, 
  timestamp, 
  boolean, 
  jsonb,
  unique
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for admin authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: varchar("role", { length: 50 }).notNull().default("teacher"),
  email: varchar("email"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Students table
export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  telegramId: varchar("telegram_id").unique(),
  telegramUsername: varchar("telegram_username"),
  name: text("name").notNull(),
  grade: varchar("grade", { length: 10 }).notNull(), // Grade 9, 10, 11, 12
  section: varchar("section", { length: 10 }), // A, B, C, etc.
  stream: varchar("stream", { length: 50 }), // Natural Science, Social Science
  isActive: boolean("is_active").default(true),
  registeredAt: timestamp("registered_at").defaultNow(),
  lastActiveAt: timestamp("last_active_at"),
});

// Teachers table
export const teachers = pgTable("teachers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  name: text("name").notNull(),
  subject: varchar("subject", { length: 100 }),
  department: varchar("department", { length: 100 }),
  telegramId: varchar("telegram_id").unique(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Exam questions table
export const examQuestions = pgTable("exam_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  examType: varchar("exam_type", { length: 20 }).notNull(), // EGSECE, ESSLCE
  grade: varchar("grade", { length: 10 }).notNull(), // Grade 10, 12
  subject: varchar("subject", { length: 100 }).notNull(),
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // Array of options
  correctAnswer: varchar("correct_answer", { length: 5 }).notNull(),
  explanation: text("explanation"),
  difficulty: varchar("difficulty", { length: 20 }).default("medium"),
  year: integer("year"),
  source: varchar("source", { length: 100 }).default("EAES"),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
});

// Groups table for Telegram groups
export const groups = pgTable("groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  telegramGroupId: varchar("telegram_group_id").unique(),
  inviteLink: text("invite_link"),
  grade: varchar("grade", { length: 10 }),
  section: varchar("section", { length: 10 }),
  subject: varchar("subject", { length: 100 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
});

// Homework table
export const homework = pgTable("homework", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  subject: varchar("subject", { length: 100 }).notNull(),
  grade: varchar("grade", { length: 10 }).notNull(),
  dueDate: timestamp("due_date"),
  fileUrl: text("file_url"),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").references(() => teachers.id),
});

// Books and resources table
export const books = pgTable("books", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  grade: varchar("grade", { length: 10 }).notNull(),
  downloadUrl: text("download_url"),
  description: text("description"),
  fileSize: varchar("file_size"),
  createdAt: timestamp("created_at").defaultNow(),
  uploadedBy: varchar("uploaded_by").references(() => users.id),
});

// AI Chat logs
export const aiChats = pgTable("ai_chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").references(() => students.id),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  language: varchar("language", { length: 10 }).default("en"), // en, am
  createdAt: timestamp("created_at").defaultNow(),
});

// Bot analytics
export const botAnalytics = pgTable("bot_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventType: varchar("event_type", { length: 50 }).notNull(), // registration, question, homework_request, etc.
  userId: varchar("user_id"),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
});

// School information
export const schoolInfo = pgTable("school_info", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
  updatedBy: varchar("updated_by").references(() => users.id),
});

// Relations
export const studentRelations = relations(students, ({ many }) => ({
  aiChats: many(aiChats),
}));

export const teacherRelations = relations(teachers, ({ one, many }) => ({
  user: one(users, { fields: [teachers.userId], references: [users.id] }),
  homework: many(homework),
}));

export const examQuestionRelations = relations(examQuestions, ({ one }) => ({
  createdBy: one(users, { fields: [examQuestions.createdBy], references: [users.id] }),
}));

export const groupRelations = relations(groups, ({ one }) => ({
  createdBy: one(users, { fields: [groups.createdBy], references: [users.id] }),
}));

export const homeworkRelations = relations(homework, ({ one }) => ({
  createdBy: one(teachers, { fields: [homework.createdBy], references: [teachers.id] }),
}));

export const aiChatRelations = relations(aiChats, ({ one }) => ({
  student: one(students, { fields: [aiChats.studentId], references: [students.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  registeredAt: true,
  lastActiveAt: true,
});

export const insertExamQuestionSchema = createInsertSchema(examQuestions).omit({
  id: true,
  createdAt: true,
});

export const insertGroupSchema = createInsertSchema(groups).omit({
  id: true,
  createdAt: true,
});

export const insertHomeworkSchema = createInsertSchema(homework).omit({
  id: true,
  createdAt: true,
});

export const insertBookSchema = createInsertSchema(books).omit({
  id: true,
  createdAt: true,
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type ExamQuestion = typeof examQuestions.$inferSelect;
export type InsertExamQuestion = z.infer<typeof insertExamQuestionSchema>;
export type Group = typeof groups.$inferSelect;
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Homework = typeof homework.$inferSelect;
export type InsertHomework = z.infer<typeof insertHomeworkSchema>;
export type Book = typeof books.$inferSelect;
export type InsertBook = z.infer<typeof insertBookSchema>;
export type AiChat = typeof aiChats.$inferSelect;
export type BotAnalytics = typeof botAnalytics.$inferSelect;
export type SchoolInfo = typeof schoolInfo.$inferSelect;
